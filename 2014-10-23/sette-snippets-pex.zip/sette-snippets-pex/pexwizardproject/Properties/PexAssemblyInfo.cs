// <copyright file="PexAssemblyInfo.cs">Copyright �  2014</copyright>
using Microsoft.Pex.Framework.Coverage;
using Microsoft.Pex.Framework.Creatable;
using Microsoft.Pex.Framework.Instrumentation;
using Microsoft.Pex.Framework.Settings;
using Microsoft.Pex.Framework.Validation;

// Microsoft.Pex.Framework.Settings
[assembly: PexAssemblySettings(TestFramework = "NUnit")]

// Microsoft.Pex.Framework.Instrumentation
[assembly: PexAssemblyUnderTest("sette-snippets")]
[assembly: PexInstrumentAssembly("sette-snippets-external")]

// Microsoft.Pex.Framework.Creatable
[assembly: PexCreatableFactoryForDelegates]

// Microsoft.Pex.Framework.Validation
[assembly: PexAllowedContractRequiresFailureAtTypeUnderTestSurface]
[assembly: PexAllowedXmlDocumentedException]

// Microsoft.Pex.Framework.Coverage
[assembly: PexCoverageFilterAssembly(PexCoverageDomain.UserOrTestCode, "sette-snippets-external")]

// Skip Microsoft.VisualBasic from instrumentation (fix VB related Context error messages)
[assembly: PexInstrumentAssembly("Microsoft.VisualBasic", InstrumentationLevel=PexInstrumentationLevel.Excluded)]
