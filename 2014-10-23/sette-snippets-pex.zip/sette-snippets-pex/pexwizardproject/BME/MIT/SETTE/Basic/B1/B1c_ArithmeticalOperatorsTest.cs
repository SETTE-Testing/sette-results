// <copyright file="B1c_ArithmeticalOperatorsTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Basic.B1;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Basic.B1
{
    [PexClass(typeof(B1c_ArithmeticalOperators))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class B1c_ArithmeticalOperatorsTest
    {
        [PexMethod]
        public int add(int x, int y)
        {
            int result = B1c_ArithmeticalOperators.add(x, y);
            return result;
        }

        [PexMethod]
        public int addAssignment(int x, int y)
        {
            int result = B1c_ArithmeticalOperators.addAssignment(x, y);
            return result;
        }

        [PexMethod]
        public int divide(int x, int y)
        {
            int result = B1c_ArithmeticalOperators.divide(x, y);
            return result;
        }

        [PexMethod]
        public int divideAssignment(int x, int y)
        {
            int result = B1c_ArithmeticalOperators.divideAssignment(x, y);
            return result;
        }

        [PexMethod]
        public int modulo(int x, int y)
        {
            int result = B1c_ArithmeticalOperators.modulo(x, y);
            return result;
        }

        [PexMethod]
        public int moduloAssignment(int x, int y)
        {
            int result = B1c_ArithmeticalOperators.moduloAssignment(x, y);
            return result;
        }

        [PexMethod]
        public int multiply(int x, int y)
        {
            int result = B1c_ArithmeticalOperators.multiply(x, y);
            return result;
        }

        [PexMethod]
        public int multiplyAssignment(int x, int y)
        {
            int result = B1c_ArithmeticalOperators.multiplyAssignment(x, y);
            return result;
        }

        [PexMethod]
        public int postfixMinusMinus(int x)
        {
            int result = B1c_ArithmeticalOperators.postfixMinusMinus(x);
            return result;
        }

        [PexMethod]
        public int postfixPlusplus(int x)
        {
            int result = B1c_ArithmeticalOperators.postfixPlusplus(x);
            return result;
        }

        [PexMethod]
        public int substract(int x, int y)
        {
            int result = B1c_ArithmeticalOperators.substract(x, y);
            return result;
        }

        [PexMethod]
        public int substractAssignment(int x, int y)
        {
            int result = B1c_ArithmeticalOperators.substractAssignment(x, y);
            return result;
        }

        [PexMethod]
        public int unaryMinus(int x)
        {
            int result = B1c_ArithmeticalOperators.unaryMinus(x);
            return result;
        }

        [PexMethod]
        public int unaryMinusMinus(int x)
        {
            int result = B1c_ArithmeticalOperators.unaryMinusMinus(x);
            return result;
        }

        [PexMethod]
        public int unaryPlus(int x)
        {
            int result = B1c_ArithmeticalOperators.unaryPlus(x);
            return result;
        }

        [PexMethod]
        public int unaryPlusPlus(int x)
        {
            int result = B1c_ArithmeticalOperators.unaryPlusPlus(x);
            return result;
        }
    }
}
