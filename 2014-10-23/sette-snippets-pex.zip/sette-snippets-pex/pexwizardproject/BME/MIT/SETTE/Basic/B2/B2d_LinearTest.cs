// <copyright file="B2d_LinearTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Basic.B2;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Basic.B2
{
    [PexClass(typeof(B2d_Linear))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class B2d_LinearTest
    {
        [PexMethod]
        public bool oneParamDouble(double x)
        {
            bool result = B2d_Linear.oneParamDouble(x);
            return result;
        }

        [PexMethod]
        public bool oneParamFloat(float x)
        {
            bool result = B2d_Linear.oneParamFloat(x);
            return result;
        }

        [PexMethod]
        public bool oneParamInt(int x)
        {
            bool result = B2d_Linear.oneParamInt(x);
            return result;
        }

        [PexMethod]
        public bool oneParamIntNoSolution(int x)
        {
            bool result = B2d_Linear.oneParamIntNoSolution(x);
            return result;
        }

        [PexMethod]
        public bool threeParamsDouble(
            double x,
            double y,
            double z
        )
        {
            bool result = B2d_Linear.threeParamsDouble(x, y, z);
            return result;
        }

        [PexMethod]
        public bool threeParamsFloat(
            float x,
            float y,
            float z
        )
        {
            bool result = B2d_Linear.threeParamsFloat(x, y, z);
            return result;
        }

        [PexMethod]
        public bool threeParamsInt(
            int x,
            int y,
            int z
        )
        {
            bool result = B2d_Linear.threeParamsInt(x, y, z);
            return result;
        }

        [PexMethod]
        public bool threeParamsIntNoSolution(
            int x,
            int y,
            int z
        )
        {
            bool result = B2d_Linear.threeParamsIntNoSolution(x, y, z);
            return result;
        }

        [PexMethod]
        public bool twoParamsDouble(double x, double y)
        {
            bool result = B2d_Linear.twoParamsDouble(x, y);
            return result;
        }

        [PexMethod]
        public bool twoParamsFloat(float x, float y)
        {
            bool result = B2d_Linear.twoParamsFloat(x, y);
            return result;
        }

        [PexMethod]
        public bool twoParamsInt(int x, int y)
        {
            bool result = B2d_Linear.twoParamsInt(x, y);
            return result;
        }

        [PexMethod]
        public bool twoParamsIntNoSolution(int x, int y)
        {
            bool result = B2d_Linear.twoParamsIntNoSolution(x, y);
            return result;
        }
    }
}
