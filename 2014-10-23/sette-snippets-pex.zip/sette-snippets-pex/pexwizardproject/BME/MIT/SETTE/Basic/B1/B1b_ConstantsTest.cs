// <copyright file="B1b_ConstantsTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Basic.B1;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Basic.B1
{
    [PexClass(typeof(B1b_Constants))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class B1b_ConstantsTest
    {
        [PexMethod]
        public bool constBoolean()
        {
            bool result = B1b_Constants.constBoolean();
            return result;
        }

        [PexMethod]
        public byte constByte()
        {
            byte result = B1b_Constants.constByte();
            return result;
        }

        [PexMethod]
        public char constChar()
        {
            char result = B1b_Constants.constChar();
            return result;
        }

        [PexMethod]
        public double constDouble()
        {
            double result = B1b_Constants.constDouble();
            return result;
        }

        [PexMethod]
        public float constFloat()
        {
            float result = B1b_Constants.constFloat();
            return result;
        }

        [PexMethod]
        public int constInt()
        {
            int result = B1b_Constants.constInt();
            return result;
        }

        [PexMethod]
        public long constLong()
        {
            long result = B1b_Constants.constLong();
            return result;
        }

        [PexMethod]
        public short constShort()
        {
            short result = B1b_Constants.constShort();
            return result;
        }
    }
}
