// <copyright file="B4_UnsafeArraysTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Basic.B4;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Basic.B4
{
    [PexClass(typeof(B4_UnsafeArrays))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class B4_UnsafeArraysTest
    {
        [PexMethod]
        public int fromParams(
            int x,
            int y,
            int z
        )
        {
            int result = B4_UnsafeArrays.fromParams(x, y, z);
            return result;
        }

        [PexMethod]
        public int fromParamsWithIndex(
            int x,
            int y,
            int z,
            int index
        )
        {
            int result = B4_UnsafeArrays.fromParamsWithIndex(x, y, z, index);
            return result;
        }

        [PexMethod]
        public int guessLength(int length)
        {
            int result = B4_UnsafeArrays.guessLength(length);
            return result;
        }

        [PexMethod]
        public int guessOneArray(int[] numbers)
        {
            int result = B4_UnsafeArrays.guessOneArray(numbers);
            return result;
        }

        [PexMethod]
        public int guessOneArrayWithLength(int[] numbers)
        {
            int result = B4_UnsafeArrays.guessOneArrayWithLength(numbers);
            return result;
        }

        [PexMethod]
        public int indexParam(int index)
        {
            int result = B4_UnsafeArrays.indexParam(index);
            return result;
        }

        [PexMethod]
        public int[] iterateWithFor(int[] numbers)
        {
            int[] result = B4_UnsafeArrays.iterateWithFor(numbers);
            return result;
        }

        [PexMethod]
        public int[] iterateWithForeach(int[] numbers)
        {
            int[] result = B4_UnsafeArrays.iterateWithForeach(numbers);
            return result;
        }

        [PexMethod]
        public int twoArrays(int[] numbers1, int[] numbers2)
        {
            int result = B4_UnsafeArrays.twoArrays(numbers1, numbers2);
            return result;
        }
    }
}
