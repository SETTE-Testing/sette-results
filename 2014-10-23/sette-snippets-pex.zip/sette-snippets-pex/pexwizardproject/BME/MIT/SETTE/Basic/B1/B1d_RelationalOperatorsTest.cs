// <copyright file="B1d_RelationalOperatorsTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Basic.B1;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Basic.B1
{
    [PexClass(typeof(B1d_RelationalOperators))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class B1d_RelationalOperatorsTest
    {
        [PexMethod]
        public bool and(bool x, bool y)
        {
            bool result = B1d_RelationalOperators.and(x, y);
            return result;
        }

        [PexMethod]
        public bool equal(int x, int y)
        {
            bool result = B1d_RelationalOperators.equal(x, y);
            return result;
        }

        [PexMethod]
        public bool greater(int x, int y)
        {
            bool result = B1d_RelationalOperators.greater(x, y);
            return result;
        }

        [PexMethod]
        public bool greaterOrEqual(int x, int y)
        {
            bool result = B1d_RelationalOperators.greaterOrEqual(x, y);
            return result;
        }

        [PexMethod]
        public bool negate(bool x)
        {
            bool result = B1d_RelationalOperators.negate(x);
            return result;
        }

        [PexMethod]
        public bool notEqual(int x, int y)
        {
            bool result = B1d_RelationalOperators.notEqual(x, y);
            return result;
        }

        [PexMethod]
        public bool or(bool x, bool y)
        {
            bool result = B1d_RelationalOperators.or(x, y);
            return result;
        }

        [PexMethod]
        public bool smaller(int x, int y)
        {
            bool result = B1d_RelationalOperators.smaller(x, y);
            return result;
        }

        [PexMethod]
        public bool smallerOrEqual(int x, int y)
        {
            bool result = B1d_RelationalOperators.smallerOrEqual(x, y);
            return result;
        }
    }
}
