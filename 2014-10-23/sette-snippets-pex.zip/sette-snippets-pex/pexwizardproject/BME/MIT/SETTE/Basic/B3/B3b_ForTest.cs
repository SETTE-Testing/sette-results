// <copyright file="B3b_ForTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Basic.B3;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Basic.B3
{
    [PexClass(typeof(B3b_For))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class B3b_ForTest
    {
        [PexMethod]
        public int complex(
            int x,
            int limit,
            int skip,
            int stop
        )
        {
            int result = B3b_For.complex(x, limit, skip, stop);
            return result;
        }

        [PexMethod]
        public int infinite(int x)
        {
            int result = B3b_For.infinite(x);
            return result;
        }

        [PexMethod]
        public int infiniteNotOptimalizable(int x)
        {
            int result = B3b_For.infiniteNotOptimalizable(x);
            return result;
        }

        [PexMethod]
        public int nestedLoop(int x, int y)
        {
            int result = B3b_For.nestedLoop(x, y);
            return result;
        }

        [PexMethod]
        public int nestedLoopWithLabel(int x, int y)
        {
            int result = B3b_For.nestedLoopWithLabel(x, y);
            return result;
        }

        [PexMethod]
        public int withConditionAndLimit(int x)
        {
            int result = B3b_For.withConditionAndLimit(x);
            return result;
        }

        [PexMethod]
        public int withConditionNoLimit(int x)
        {
            int result = B3b_For.withConditionNoLimit(x);
            return result;
        }

        [PexMethod]
        public int withContinueBreak(int x)
        {
            int result = B3b_For.withContinueBreak(x);
            return result;
        }

        [PexMethod]
        public int withLimit(int x)
        {
            int result = B3b_For.withLimit(x);
            return result;
        }
    }
}
