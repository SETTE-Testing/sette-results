// <copyright file="B6a_CheckedExceptionsTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Basic.B6;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Basic.B6
{
    [PexClass(typeof(B6a_CheckedExceptions))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class B6a_CheckedExceptionsTest
    {
        [PexMethod]
        public void always()
        {
            B6a_CheckedExceptions.always();
        }

        [PexMethod]
        public int call(int x, int y)
        {
            int result = B6a_CheckedExceptions.call(x, y);
            return result;
        }

        [PexMethod]
        public int conditionalAndLoop(int x)
        {
            int result = B6a_CheckedExceptions.conditionalAndLoop(x);
            return result;
        }

        [PexMethod]
        public int recursive(int x)
        {
            int result = B6a_CheckedExceptions.recursive(x);
            return result;
        }

        [PexMethod]
        public int tryCatch(int x, int y)
        {
            int result = B6a_CheckedExceptions.tryCatch(x, y);
            return result;
        }

        [PexMethod]
        public int tryCatchFinally(
            int x,
            int y,
            int z
        )
        {
            int result = B6a_CheckedExceptions.tryCatchFinally(x, y, z);
            return result;
        }
    }
}
