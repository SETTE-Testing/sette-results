// <copyright file="B2c_SwitchTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Basic.B2;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Basic.B2
{
    [PexClass(typeof(B2c_Switch))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class B2c_SwitchTest
    {
        [PexMethod]
        public int missingBreaks(int x)
        {
            int result = B2c_Switch.missingBreaks(x);
            return result;
        }

        [PexMethod]
        public int simple(int x)
        {
            int result = B2c_Switch.simple(x);
            return result;
        }

        [PexMethod]
        public int withReturn(int x)
        {
            int result = B2c_Switch.withReturn(x);
            return result;
        }
    }
}
