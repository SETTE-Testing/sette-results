// <copyright file="B4_SafeArraysTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Basic.B4;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Basic.B4
{
    [PexClass(typeof(B4_SafeArrays))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class B4_SafeArraysTest
    {
        [PexMethod]
        public int fromParams(
            int x,
            int y,
            int z
        )
        {
            int result = B4_SafeArrays.fromParams(x, y, z);
            return result;
        }

        [PexMethod]
        public int fromParamsWithIndex(
            int x,
            int y,
            int z,
            int index
        )
        {
            int result = B4_SafeArrays.fromParamsWithIndex(x, y, z, index);
            return result;
        }

        [PexMethod]
        public int guessLength(int length)
        {
            int result = B4_SafeArrays.guessLength(length);
            return result;
        }

        [PexMethod]
        public int guessOneArray(int[] numbers)
        {
            int result = B4_SafeArrays.guessOneArray(numbers);
            return result;
        }

        [PexMethod]
        public int guessOneArrayWithLength(int[] numbers)
        {
            int result = B4_SafeArrays.guessOneArrayWithLength(numbers);
            return result;
        }

        [PexMethod]
        public int indexParam(int index)
        {
            int result = B4_SafeArrays.indexParam(index);
            return result;
        }

        [PexMethod]
        public int[] iterateWithFor(int[] numbers)
        {
            int[] result = B4_SafeArrays.iterateWithFor(numbers);
            return result;
        }

        [PexMethod]
        public int[] iterateWithForeach(int[] numbers)
        {
            int[] result = B4_SafeArrays.iterateWithForeach(numbers);
            return result;
        }

        [PexMethod]
        public int twoArrays(int[] numbers1, int[] numbers2)
        {
            int result = B4_SafeArrays.twoArrays(numbers1, numbers2);
            return result;
        }
    }
}
