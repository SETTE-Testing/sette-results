// <copyright file="B1a_PrimitiveTypesTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Basic.B1;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Basic.B1
{
    [PexClass(typeof(B1a_PrimitiveTypes))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class B1a_PrimitiveTypesTest
    {
        [PexMethod]
        public byte oneParamByte(byte x)
        {
            byte result = B1a_PrimitiveTypes.oneParamByte(x);
            return result;
        }

        [PexMethod]
        public char oneParamChar(char x)
        {
            char result = B1a_PrimitiveTypes.oneParamChar(x);
            return result;
        }

        [PexMethod]
        public double oneParamDouble(double x)
        {
            double result = B1a_PrimitiveTypes.oneParamDouble(x);
            return result;
        }

        [PexMethod]
        public float oneParamFloat(float x)
        {
            float result = B1a_PrimitiveTypes.oneParamFloat(x);
            return result;
        }

        [PexMethod]
        public int oneParamInt(int x)
        {
            int result = B1a_PrimitiveTypes.oneParamInt(x);
            return result;
        }

        [PexMethod]
        public long oneParamLong(long x)
        {
            long result = B1a_PrimitiveTypes.oneParamLong(x);
            return result;
        }

        [PexMethod]
        public short oneParamShort(short x)
        {
            short result = B1a_PrimitiveTypes.oneParamShort(x);
            return result;
        }

        [PexMethod]
        public bool oneParambool(bool x)
        {
            bool result = B1a_PrimitiveTypes.oneParambool(x);
            return result;
        }

        [PexMethod]
        public byte twoParamByte(byte x, byte y)
        {
            byte result = B1a_PrimitiveTypes.twoParamByte(x, y);
            return result;
        }

        [PexMethod]
        public char twoParamChar(char x, char y)
        {
            char result = B1a_PrimitiveTypes.twoParamChar(x, y);
            return result;
        }

        [PexMethod]
        public double twoParamDouble(double x, double y)
        {
            double result = B1a_PrimitiveTypes.twoParamDouble(x, y);
            return result;
        }

        [PexMethod]
        public float twoParamFloat(float x, float y)
        {
            float result = B1a_PrimitiveTypes.twoParamFloat(x, y);
            return result;
        }

        [PexMethod]
        public int twoParamInt(int x, int y)
        {
            int result = B1a_PrimitiveTypes.twoParamInt(x, y);
            return result;
        }

        [PexMethod]
        public long twoParamLong(long x, long y)
        {
            long result = B1a_PrimitiveTypes.twoParamLong(x, y);
            return result;
        }

        [PexMethod]
        public short twoParamShort(short x, short y)
        {
            short result = B1a_PrimitiveTypes.twoParamShort(x, y);
            return result;
        }

        [PexMethod]
        public bool twoParambool(bool x, bool y)
        {
            bool result = B1a_PrimitiveTypes.twoParambool(x, y);
            return result;
        }
    }
}
