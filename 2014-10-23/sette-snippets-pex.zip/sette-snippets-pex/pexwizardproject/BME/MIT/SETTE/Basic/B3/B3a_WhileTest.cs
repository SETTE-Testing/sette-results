// <copyright file="B3a_WhileTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Basic.B3;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Basic.B3
{
    [PexClass(typeof(B3a_While))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class B3a_WhileTest
    {
        [PexMethod]
        public int complex(
            int x,
            int limit,
            int skip,
            int stop
        )
        {
            int result = B3a_While.complex(x, limit, skip, stop);
            return result;
        }

        [PexMethod]
        public int infinite(int x)
        {
            int result = B3a_While.infinite(x);
            return result;
        }

        [PexMethod]
        public int infiniteNotOptimalizable(int x)
        {
            int result = B3a_While.infiniteNotOptimalizable(x);
            return result;
        }

        [PexMethod]
        public int nestedLoop(int x, int y)
        {
            int result = B3a_While.nestedLoop(x, y);
            return result;
        }

        [PexMethod]
        public int nestedLoopWithLabel(int x, int y)
        {
            int result = B3a_While.nestedLoopWithLabel(x, y);
            return result;
        }

        [PexMethod]
        public int withConditionAndLimit(int x)
        {
            int result = B3a_While.withConditionAndLimit(x);
            return result;
        }

        [PexMethod]
        public int withConditionNoLimit(int x)
        {
            int result = B3a_While.withConditionNoLimit(x);
            return result;
        }

        [PexMethod]
        public int withContinueBreak(int x)
        {
            int result = B3a_While.withContinueBreak(x);
            return result;
        }

        [PexMethod]
        public int withLimit(int x)
        {
            int result = B3a_While.withLimit(x);
            return result;
        }
    }
}
