// <copyright file="B5b_LimitedRecursiveTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Basic.B5;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Basic.B5
{
    [PexClass(typeof(B5b_LimitedRecursive))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class B5b_LimitedRecursiveTest
    {
        [PexMethod]
        public int fibonacci(int x)
        {
            int result = B5b_LimitedRecursive.fibonacci(x);
            return result;
        }

        [PexMethod]
        public int simple(int x)
        {
            int result = B5b_LimitedRecursive.simple(x);
            return result;
        }
    }
}
