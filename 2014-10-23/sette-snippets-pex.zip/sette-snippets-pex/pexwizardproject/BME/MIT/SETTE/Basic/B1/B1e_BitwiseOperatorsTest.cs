// <copyright file="B1e_BitwiseOperatorsTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Basic.B1;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Basic.B1
{
    [PexClass(typeof(B1e_BitwiseOperators))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class B1e_BitwiseOperatorsTest
    {
        [PexMethod]
        public int and(int x, int y)
        {
            int result = B1e_BitwiseOperators.and(x, y);
            return result;
        }

        [PexMethod]
        public int andAssignment(int x, int y)
        {
            int result = B1e_BitwiseOperators.andAssignment(x, y);
            return result;
        }

        [PexMethod]
        public int negate(int x)
        {
            int result = B1e_BitwiseOperators.negate(x);
            return result;
        }

        [PexMethod]
        public int or(int x, int y)
        {
            int result = B1e_BitwiseOperators.or(x, y);
            return result;
        }

        [PexMethod]
        public int orAssignment(int x, int y)
        {
            int result = B1e_BitwiseOperators.orAssignment(x, y);
            return result;
        }

        [PexMethod]
        public int shiftLeft(int x, int y)
        {
            int result = B1e_BitwiseOperators.shiftLeft(x, y);
            return result;
        }

        [PexMethod]
        public int shiftLeftAssignment(int x, int y)
        {
            int result = B1e_BitwiseOperators.shiftLeftAssignment(x, y);
            return result;
        }

        [PexMethod]
        public int shiftRight(int x, int y)
        {
            int result = B1e_BitwiseOperators.shiftRight(x, y);
            return result;
        }

        [PexMethod]
        public int shiftRightAssignment(int x, int y)
        {
            int result = B1e_BitwiseOperators.shiftRightAssignment(x, y);
            return result;
        }

        [PexMethod]
        public int shiftRightUnsigned(int x, int y)
        {
            int result = B1e_BitwiseOperators.shiftRightUnsigned(x, y);
            return result;
        }

        [PexMethod]
        public int shiftRightUnsignedAssignment(int x, int y)
        {
            int result = B1e_BitwiseOperators.shiftRightUnsignedAssignment(x, y);
            return result;
        }

        [PexMethod]
        public int xor(int x, int y)
        {
            int result = B1e_BitwiseOperators.xor(x, y);
            return result;
        }

        [PexMethod]
        public int xorAssignment(int x, int y)
        {
            int result = B1e_BitwiseOperators.xorAssignment(x, y);
            return result;
        }
    }
}
