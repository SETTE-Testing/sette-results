// <copyright file="B2a_IfElseTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Basic.B2;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Basic.B2
{
    [PexClass(typeof(B2a_IfElse))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class B2a_IfElseTest
    {
        [PexMethod]
        public int oneParamBoolean(bool x)
        {
            int result = B2a_IfElse.oneParamBoolean(x);
            return result;
        }

        [PexMethod]
        public int oneParamDouble(double x)
        {
            int result = B2a_IfElse.oneParamDouble(x);
            return result;
        }

        [PexMethod]
        public int oneParamInt(int x)
        {
            int result = B2a_IfElse.oneParamInt(x);
            return result;
        }

        [PexMethod]
        public int twoParamsBoolean(bool x, bool y)
        {
            int result = B2a_IfElse.twoParamsBoolean(x, y);
            return result;
        }

        [PexMethod]
        public int twoParamsDouble(double x, double y)
        {
            int result = B2a_IfElse.twoParamsDouble(x, y);
            return result;
        }

        [PexMethod]
        public int twoParamsInt(int x, int y)
        {
            int result = B2a_IfElse.twoParamsInt(x, y);
            return result;
        }
    }
}
