// <copyright file="B6b_UncheckedExceptionsTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Basic.B6;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Basic.B6
{
    [PexClass(typeof(B6b_UncheckedExceptions))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class B6b_UncheckedExceptionsTest
    {
        [PexMethod]
        public void always()
        {
            B6b_UncheckedExceptions.always();
        }

        [PexMethod]
        public int call(int x, int y)
        {
            int result = B6b_UncheckedExceptions.call(x, y);
            return result;
        }

        [PexMethod]
        public int conditionalAndLoop(int x)
        {
            int result = B6b_UncheckedExceptions.conditionalAndLoop(x);
            return result;
        }

        [PexMethod]
        public int recursive(int x)
        {
            int result = B6b_UncheckedExceptions.recursive(x);
            return result;
        }

        [PexMethod]
        public int tryCatch(int x, int y)
        {
            int result = B6b_UncheckedExceptions.tryCatch(x, y);
            return result;
        }

        [PexMethod]
        public int tryCatchFinally(
            int x,
            int y,
            int z
        )
        {
            int result = B6b_UncheckedExceptions.tryCatchFinally(x, y, z);
            return result;
        }
    }
}
