// <copyright file="B6c_CommonRuntimeExceptionsTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Basic.B6;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Basic.B6
{
    [PexClass(typeof(B6c_CommonRuntimeExceptions))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class B6c_CommonRuntimeExceptionsTest
    {
        [PexMethod]
        public int arithmeticException(bool b)
        {
            int result = B6c_CommonRuntimeExceptions.arithmeticException(b);
            return result;
        }

        [PexMethod]
        public int arrayIndexOutOfBoundsException(bool b)
        {
            int result = B6c_CommonRuntimeExceptions.arrayIndexOutOfBoundsException(b);
            return result;
        }

        [PexMethod]
        public int classCastException(bool b)
        {
            int result = B6c_CommonRuntimeExceptions.classCastException(b);
            return result;
        }

        [PexMethod]
        public int illegalArgumentException(bool b)
        {
            int result = B6c_CommonRuntimeExceptions.illegalArgumentException(b);
            return result;
        }

        [PexMethod]
        public int illegalStateException(bool b)
        {
            int result = B6c_CommonRuntimeExceptions.illegalStateException(b);
            return result;
        }

        [PexMethod]
        public int indexOutOfBoundsException(bool b)
        {
            int result = B6c_CommonRuntimeExceptions.indexOutOfBoundsException(b);
            return result;
        }

        [PexMethod]
        public int nullPointerException(bool b)
        {
            int result = B6c_CommonRuntimeExceptions.nullPointerException(b);
            return result;
        }

        [PexMethod]
        public int securityException(bool b)
        {
            int result = B6c_CommonRuntimeExceptions.securityException(b);
            return result;
        }

        [PexMethod]
        public int unsupportedOperationException(bool b)
        {
            int result = B6c_CommonRuntimeExceptions.unsupportedOperationException(b);
            return result;
        }
    }
}
