// <copyright file="B2b_TernaryTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Basic.B2;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Basic.B2
{
    [PexClass(typeof(B2b_Ternary))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class B2b_TernaryTest
    {
        [PexMethod]
        public bool oneParamBoolean(bool x)
        {
            bool result = B2b_Ternary.oneParamBoolean(x);
            return result;
        }

        [PexMethod]
        public int oneParamInt(int x)
        {
            int result = B2b_Ternary.oneParamInt(x);
            return result;
        }

        [PexMethod]
        public bool twoParamsBoolean(bool x, bool y)
        {
            bool result = B2b_Ternary.twoParamsBoolean(x, y);
            return result;
        }

        [PexMethod]
        public int twoParamsInt(int x, int y)
        {
            int result = B2b_Ternary.twoParamsInt(x, y);
            return result;
        }
    }
}
