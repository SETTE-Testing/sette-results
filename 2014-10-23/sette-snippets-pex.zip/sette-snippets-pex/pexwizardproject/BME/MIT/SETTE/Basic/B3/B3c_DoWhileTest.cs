// <copyright file="B3c_DoWhileTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Basic.B3;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Basic.B3
{
    [PexClass(typeof(B3c_DoWhile))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class B3c_DoWhileTest
    {
        [PexMethod]
        public int complex(
            int x,
            int limit,
            int skip,
            int stop
        )
        {
            int result = B3c_DoWhile.complex(x, limit, skip, stop);
            return result;
        }

        [PexMethod]
        public int infinite(int x)
        {
            int result = B3c_DoWhile.infinite(x);
            return result;
        }

        [PexMethod]
        public int infiniteNotOptimalizable(int x)
        {
            int result = B3c_DoWhile.infiniteNotOptimalizable(x);
            return result;
        }

        [PexMethod]
        public int nestedLoop(int x, int y)
        {
            int result = B3c_DoWhile.nestedLoop(x, y);
            return result;
        }

        [PexMethod]
        public int nestedLoopWithLabel(int x, int y)
        {
            int result = B3c_DoWhile.nestedLoopWithLabel(x, y);
            return result;
        }

        [PexMethod]
        public int withConditionAndLimit(int x)
        {
            int result = B3c_DoWhile.withConditionAndLimit(x);
            return result;
        }

        [PexMethod]
        public int withConditionNoLimit(int x)
        {
            int result = B3c_DoWhile.withConditionNoLimit(x);
            return result;
        }

        [PexMethod]
        public int withContinueBreak(int x)
        {
            int result = B3c_DoWhile.withContinueBreak(x);
            return result;
        }

        [PexMethod]
        public int withLimit(int x)
        {
            int result = B3c_DoWhile.withLimit(x);
            return result;
        }
    }
}
