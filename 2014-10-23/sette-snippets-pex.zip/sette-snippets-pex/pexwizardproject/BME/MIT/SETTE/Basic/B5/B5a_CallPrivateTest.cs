// <copyright file="B5a_CallPrivateTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Basic.B5;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Basic.B5
{
    [PexClass(typeof(B5a_CallPrivate))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class B5a_CallPrivateTest
    {
        [PexMethod]
        public int conditionalCall(
            int x,
            int y,
            bool z
        )
        {
            int result = B5a_CallPrivate.conditionalCall(x, y, z);
            return result;
        }

        [PexMethod]
        public int simple(int x, int y)
        {
            int result = B5a_CallPrivate.simple(x, y);
            return result;
        }

        [PexMethod]
        public int useReturnValue(int x, int y)
        {
            int result = B5a_CallPrivate.useReturnValue(x, y);
            return result;
        }
    }
}
