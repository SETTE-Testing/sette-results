// <copyright file="B5b_UnlimitedRecursiveTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Basic.B5;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Basic.B5
{
    [PexClass(typeof(B5b_UnlimitedRecursive))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class B5b_UnlimitedRecursiveTest
    {
        [PexMethod]
        public int fibonacci(int x)
        {
            int result = B5b_UnlimitedRecursive.fibonacci(x);
            return result;
        }

        [PexMethod]
        public int simple(int x)
        {
            int result = B5b_UnlimitedRecursive.simple(x);
            return result;
        }
    }
}
