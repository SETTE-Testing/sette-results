// <copyright file="B2d_NonlinearTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Basic.B2;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Basic.B2
{
    [PexClass(typeof(B2d_Nonlinear))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class B2d_NonlinearTest
    {
        [PexMethod]
        public bool quadraticDouble(double x1, double x2)
        {
            bool result = B2d_Nonlinear.quadraticDouble(x1, x2);
            return result;
        }

        [PexMethod]
        public bool quadraticDoubleNoSolution(double x1, double x2)
        {
            bool result = B2d_Nonlinear.quadraticDoubleNoSolution(x1, x2);
            return result;
        }

        [PexMethod]
        public bool quadraticFloat(float x1, float x2)
        {
            bool result = B2d_Nonlinear.quadraticFloat(x1, x2);
            return result;
        }

        [PexMethod]
        public bool quadraticFloatNoSolution(float x1, float x2)
        {
            bool result = B2d_Nonlinear.quadraticFloatNoSolution(x1, x2);
            return result;
        }

        [PexMethod]
        public bool quadraticInt(int x1, int x2)
        {
            bool result = B2d_Nonlinear.quadraticInt(x1, x2);
            return result;
        }

        [PexMethod]
        public bool quadraticIntNoSolution(int x1, int x2)
        {
            bool result = B2d_Nonlinear.quadraticIntNoSolution(x1, x2);
            return result;
        }
    }
}
