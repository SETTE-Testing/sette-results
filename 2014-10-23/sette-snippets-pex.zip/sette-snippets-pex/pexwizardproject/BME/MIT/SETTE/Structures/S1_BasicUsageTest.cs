// <copyright file="S1_BasicUsageTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Structures;
using BME.MIT.SETTE.Structures.Dependencies;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Structures
{
    [PexClass(typeof(S1_BasicUsage))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class S1_BasicUsageTest
    {
        [PexMethod]
        public CoordinateStructure returnStructure(CoordinateStructure c)
        {
            CoordinateStructure result = S1_BasicUsage.returnStructure(c);
            return result;
        }

        [PexMethod]
        public CoordinateStructure returnStructureParams(int x, int y)
        {
            CoordinateStructure result = S1_BasicUsage.returnStructureParams(x, y);
            return result;
        }

        [PexMethod]
        public int useStructure(CoordinateStructure c)
        {
            int result = S1_BasicUsage.useStructure(c);
            return result;
        }

        [PexMethod]
        public int useStructureParams(int x, int y)
        {
            int result = S1_BasicUsage.useStructureParams(x, y);
            return result;
        }
    }
}
