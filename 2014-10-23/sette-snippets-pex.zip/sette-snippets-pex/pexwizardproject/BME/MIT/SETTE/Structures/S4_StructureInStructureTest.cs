// <copyright file="S4_StructureInStructureTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Structures;
using BME.MIT.SETTE.Structures.Dependencies;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Structures
{
    [PexClass(typeof(S4_StructureInStructure))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class S4_StructureInStructureTest
    {
        [PexMethod]
        public int guess(SegmentStructure s)
        {
            int result = S4_StructureInStructure.guess(s);
            return result;
        }

        [PexMethod]
        public int guessCoordinates(CoordinateStructure p1, CoordinateStructure p2)
        {
            int result = S4_StructureInStructure.guessCoordinates(p1, p2);
            return result;
        }

        [PexMethod]
        public int guessParams(
            int x1,
            int y1,
            int x2,
            int y2
        )
        {
            int result = S4_StructureInStructure.guessParams(x1, y1, x2, y2);
            return result;
        }
    }
}
