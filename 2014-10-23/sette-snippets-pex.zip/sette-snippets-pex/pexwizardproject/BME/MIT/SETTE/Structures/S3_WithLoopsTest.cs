// <copyright file="S3_WithLoopsTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Structures;
using BME.MIT.SETTE.Structures.Dependencies;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Structures
{
    [PexClass(typeof(S3_WithLoops))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class S3_WithLoopsTest
    {
        [PexMethod]
        public int arrayOfStructures(CoordinateStructure[] cs)
        {
            int result = S3_WithLoops.arrayOfStructures(cs);
            return result;
        }

        [PexMethod]
        public int arrayOfStructuresParams(int[] xs, int[] ys)
        {
            int result = S3_WithLoops.arrayOfStructuresParams(xs, ys);
            return result;
        }

        [PexMethod]
        public int noLimit(CoordinateStructure c, int max)
        {
            int result = S3_WithLoops.noLimit(c, max);
            return result;
        }

        [PexMethod]
        public int noLimitParams(
            int x,
            int y,
            int max
        )
        {
            int result = S3_WithLoops.noLimitParams(x, y, max);
            return result;
        }

        [PexMethod]
        public int withLimit(CoordinateStructure c, int max)
        {
            int result = S3_WithLoops.withLimit(c, max);
            return result;
        }

        [PexMethod]
        public int withLimitParams(
            int x,
            int y,
            int max
        )
        {
            int result = S3_WithLoops.withLimitParams(x, y, max);
            return result;
        }
    }
}
