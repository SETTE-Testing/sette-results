// <copyright file="S2_WithConditionalsTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Structures;
using BME.MIT.SETTE.Structures.Dependencies;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Structures
{
    [PexClass(typeof(S2_WithConditionals))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class S2_WithConditionalsTest
    {
        [PexMethod]
        public int oneStructure(CoordinateStructure c)
        {
            int result = S2_WithConditionals.oneStructure(c);
            return result;
        }

        [PexMethod]
        public int oneStructureParams(int x, int y)
        {
            int result = S2_WithConditionals.oneStructureParams(x, y);
            return result;
        }

        [PexMethod]
        public int twoStructures(CoordinateStructure c1, CoordinateStructure c2)
        {
            int result = S2_WithConditionals.twoStructures(c1, c2);
            return result;
        }

        [PexMethod]
        public int twoStructuresParams(
            int x1,
            int y1,
            int x2,
            int y2
        )
        {
            int result = S2_WithConditionals.twoStructuresParams(x1, y1, x2, y2);
            return result;
        }
    }
}
