// <copyright file="G1_FunctionsTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Generics;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Generics
{
    [PexClass(typeof(G1_Functions))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class G1_FunctionsTest
    {
        [PexGenericArguments(typeof(int))]
        [PexMethod]
        public int guessType<T>(T o)
        {
            int result = G1_Functions.guessType<T>(o);
            return result;
        }

        [PexGenericArguments(typeof(int))]
        [PexMethod]
        public int guessTypeAndUse<T>(T o)
        {
            int result = G1_Functions.guessTypeAndUse<T>(o);
            return result;
        }

        [PexMethod]
        public int guessTypeWithExtends<T>(T o)
            where T : IComparable<T>
        {
            int result = G1_Functions.guessTypeWithExtends<T>(o);
            return result;
        }

        [PexMethod]
        public int guessTypeWithExtendsAndUse<T>(T o)
            where T : IComparable<T>
        {
            int result = G1_Functions.guessTypeWithExtendsAndUse<T>(o);
            return result;
        }
    }
}
