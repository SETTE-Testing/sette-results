// <copyright file="G2_ObjectsTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Generics;
using BME.MIT.SETTE.Generics.Dependencies;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Generics
{
    [PexClass(typeof(G2_Objects))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class G2_ObjectsTest
    {
        [PexMethod]
        public bool guessDescendant(IntegerTriplet obj)
        {
            bool result = G2_Objects.guessDescendant(obj);
            return result;
        }

        [PexMethod]
        public bool guessImpossible(GenericTriplet<double> obj)
        {
            bool result = G2_Objects.guessImpossible(obj);
            return result;
        }

        [PexMethod]
        public bool guessInteger(GenericTriplet<int> obj)
        {
            bool result = G2_Objects.guessInteger(obj);
            return result;
        }

        [PexGenericArguments(typeof(int))]
        [PexMethod]
        public bool guessIntegerNoHelp<T>(GenericTriplet<T> obj)
        {
            bool result = G2_Objects.guessIntegerNoHelp<T>(obj);
            return result;
        }

        [PexGenericArguments(typeof(int))]
        [PexMethod]
        public bool guessSafe<T>(SafeGenericTriplet<T> obj)
        {
            bool result = G2_Objects.guessSafe<T>(obj);
            return result;
        }

        [PexGenericArguments(typeof(int))]
        [PexMethod]
        public bool guessSafeNoHelp<T>(GenericTriplet<T> obj)
        {
            bool result = G2_Objects.guessSafeNoHelp<T>(obj);
            return result;
        }
    }
}
