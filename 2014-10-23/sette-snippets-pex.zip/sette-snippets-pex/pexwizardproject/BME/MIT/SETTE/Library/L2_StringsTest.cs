// <copyright file="L2_StringsTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Library;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Library
{
    [PexClass(typeof(L2_Strings))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class L2_StringsTest
    {
        [PexMethod]
        public string add(string a, string b)
        {
            string result = L2_Strings.add(a, b);
            return result;
        }

        [PexMethod]
        public int addWithCondition(string a, string b)
        {
            int result = L2_Strings.addWithCondition(a, b);
            return result;
        }

        [PexMethod]
        public int charAt(string s)
        {
            int result = L2_Strings.charAt(s);
            return result;
        }

        [PexMethod]
        public int compareTo(string s)
        {
            int result = L2_Strings.compareTo(s);
            return result;
        }

        [PexMethod]
        public int compareToIgnoreCase(string s)
        {
            int result = L2_Strings.compareToIgnoreCase(s);
            return result;
        }

        [PexMethod]
        public int equality(string s)
        {
            int result = L2_Strings.equality(s);
            return result;
        }

        [PexMethod]
        public int equalityIgnoreCase(string s)
        {
            int result = L2_Strings.equalityIgnoreCase(s);
            return result;
        }

        [PexMethod]
        public int indexOf(string s)
        {
            int result = L2_Strings.indexOf(s);
            return result;
        }

        [PexMethod]
        public int length(string s)
        {
            int result = L2_Strings.length(s);
            return result;
        }

        [PexMethod]
        public int regionEquality(string s)
        {
            int result = L2_Strings.regionEquality(s);
            return result;
        }

        [PexMethod]
        public int startsEnds(string s)
        {
            int result = L2_Strings.startsEnds(s);
            return result;
        }

        [PexMethod]
        public int substring(string s)
        {
            int result = L2_Strings.substring(s);
            return result;
        }
    }
}
