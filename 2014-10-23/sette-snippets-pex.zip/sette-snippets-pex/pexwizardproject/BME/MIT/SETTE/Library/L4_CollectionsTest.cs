// <copyright file="L4_CollectionsTest.cs">Copyright �  2014</copyright>
using System;
using System.Collections;
using System.Collections.Generic;
using BME.MIT.SETTE.Library;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Library
{
    [PexClass(typeof(L4_Collections))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class L4_CollectionsTest
    {
        [PexMethod]
        public bool guessElementAndIndex(int a, int i)
        {
            bool result = L4_Collections.guessElementAndIndex(a, i);
            return result;
        }

        [PexMethod]
        public bool guessElements(int a, int b)
        {
            bool result = L4_Collections.guessElements(a, b);
            return result;
        }

        [PexMethod]
        public bool guessGenericListWithElement(List<int> l)
        {
            bool result = L4_Collections.guessGenericListWithElement(l);
            return result;
        }

        [PexMethod]
        public bool guessGenericListWithSize(List<int> l)
        {
            bool result = L4_Collections.guessGenericListWithSize(l);
            return result;
        }

        [PexMethod]
        public bool guessGenericVectorWithElement(ArrayList v)
        {
            bool result = L4_Collections.guessGenericVectorWithElement(v);
            return result;
        }

        [PexMethod]
        public bool guessGenericVectorWithSize(ArrayList v)
        {
            bool result = L4_Collections.guessGenericVectorWithSize(v);
            return result;
        }

        [PexMethod]
        public bool guessIndices(int a, int b)
        {
            bool result = L4_Collections.guessIndices(a, b);
            return result;
        }

        [PexMethod]
        public bool guessListWithSize(ArrayList l)
        {
            bool result = L4_Collections.guessListWithSize(l);
            return result;
        }

        [PexMethod]
        public bool guessSize(int s)
        {
            bool result = L4_Collections.guessSize(s);
            return result;
        }

        [PexMethod]
        public bool guessSizeAndElements(
            int s,
            int a,
            int b
        )
        {
            bool result = L4_Collections.guessSizeAndElements(s, a, b);
            return result;
        }

        [PexMethod]
        public bool guessVectorWithSize(ArrayList v)
        {
            bool result = L4_Collections.guessVectorWithSize(v);
            return result;
        }
    }
}
