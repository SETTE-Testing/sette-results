// <copyright file="L2_Strings_Java7Test.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Library;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Library
{
    [PexClass(typeof(L2_Strings_Java7))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class L2_Strings_Java7Test
    {
        [PexMethod]
        public int switchString(string s)
        {
            int result = L2_Strings_Java7.switchString(s);
            return result;
        }
    }
}
