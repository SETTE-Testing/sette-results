// <copyright file="LO_OtherTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Library;
using BME.MIT.SETTE.Library.Dependencies;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Library
{
    [PexClass(typeof(LO_Other))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class LO_OtherTest
    {
        [PexMethod]
        public int associatesAPIGuessDate(string s)
        {
            int result = LO_Other.associatesAPIGuessDate(s);
            return result;
        }

        [PexMethod]
        public int associatesAPIGuessValidDateFormat(string s)
        {
            int result = LO_Other.associatesAPIGuessValidDateFormat(s);
            return result;
        }

        [PexMethod]
        public int guessUUID(string s)
        {
            int result = LO_Other.guessUUID(s);
            return result;
        }

        [PexMethod]
        public int guessValidUUID(string s)
        {
            int result = LO_Other.guessValidUUID(s);
            return result;
        }

        [PexMethod]
        public int inheritsAPIGuessOneObject(FingerNumber a)
        {
            int result = LO_Other.inheritsAPIGuessOneObject(a);
            return result;
        }

        [PexMethod]
        public int inheritsAPIGuessOnePrimitive(int x)
        {
            int result = LO_Other.inheritsAPIGuessOnePrimitive(x);
            return result;
        }

        [PexMethod]
        public int inheritsAPIGuessTwoObjects(FingerNumber a, FingerNumber b)
        {
            int result = LO_Other.inheritsAPIGuessTwoObjects(a, b);
            return result;
        }

        [PexMethod]
        public int inheritsAPIGuessTwoPrimitives(int x, int y)
        {
            int result = LO_Other.inheritsAPIGuessTwoPrimitives(x, y);
            return result;
        }

        [PexMethod]
        public int regexCaseInsensitive(string s)
        {
            int result = LO_Other.regexCaseInsensitive(s);
            return result;
        }

        [PexMethod]
        public int regexCaseSensitive(string s)
        {
            int result = LO_Other.regexCaseSensitive(s);
            return result;
        }
    }
}
