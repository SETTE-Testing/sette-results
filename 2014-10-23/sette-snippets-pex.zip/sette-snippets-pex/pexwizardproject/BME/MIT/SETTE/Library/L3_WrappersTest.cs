// <copyright file="L3_WrappersTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Library;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Library
{
    [PexClass(typeof(L3_Wrappers))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class L3_WrappersTest
    {
        [PexMethod]
        public double guessDouble(double a)
        {
            double result = L3_Wrappers.guessDouble(a);
            return result;
        }

        [PexMethod]
        public int guessInteger(int a)
        {
            int result = L3_Wrappers.guessInteger(a);
            return result;
        }

        [PexMethod]
        public int integerOverflow(int a, int b)
        {
            int result = L3_Wrappers.integerOverflow(a, b);
            return result;
        }
    }
}
