// <copyright file="L1_ArithmeticsTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Library;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Library
{
    [PexClass(typeof(L1_Arithmetics))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class L1_ArithmeticsTest
    {
        [PexMethod]
        public bool abs(int x, int y)
        {
            bool result = L1_Arithmetics.abs(x, y);
            return result;
        }

        [PexMethod]
        public bool absImpossible(int x, int y)
        {
            bool result = L1_Arithmetics.absImpossible(x, y);
            return result;
        }

        [PexMethod]
        public bool cbrt(double x)
        {
            bool result = L1_Arithmetics.cbrt(x);
            return result;
        }

        [PexMethod]
        public bool cos(double x)
        {
            bool result = L1_Arithmetics.cos(x);
            return result;
        }

        [PexMethod]
        public bool cosImpossible(double x)
        {
            bool result = L1_Arithmetics.cosImpossible(x);
            return result;
        }

        [PexMethod]
        public bool log10GuessArgument(double x)
        {
            bool result = L1_Arithmetics.log10GuessArgument(x);
            return result;
        }

        [PexMethod]
        public bool logGuessArgument(double x)
        {
            bool result = L1_Arithmetics.logGuessArgument(x);
            return result;
        }

        [PexMethod]
        public bool logGuessBase(double x)
        {
            bool result = L1_Arithmetics.logGuessBase(x);
            return result;
        }

        [PexMethod]
        public bool logGuessBaseAndArgument(double x, double y)
        {
            bool result = L1_Arithmetics.logGuessBaseAndArgument(x, y);
            return result;
        }

        [PexMethod]
        public bool minMax(int a, int b)
        {
            bool result = L1_Arithmetics.minMax(a, b);
            return result;
        }

        [PexMethod]
        public bool minMaxImpossible(int a, int b)
        {
            bool result = L1_Arithmetics.minMaxImpossible(a, b);
            return result;
        }

        [PexMethod]
        public bool minMaxWithOrder(int a, int b)
        {
            bool result = L1_Arithmetics.minMaxWithOrder(a, b);
            return result;
        }

        [PexMethod]
        public bool powGuessBase(double x)
        {
            bool result = L1_Arithmetics.powGuessBase(x);
            return result;
        }

        [PexMethod]
        public bool powGuessBaseAndExponent(double x, double y)
        {
            bool result = L1_Arithmetics.powGuessBaseAndExponent(x, y);
            return result;
        }

        [PexMethod]
        public bool powGuessExponent(double x)
        {
            bool result = L1_Arithmetics.powGuessExponent(x);
            return result;
        }

        [PexMethod]
        public bool sin(double x)
        {
            bool result = L1_Arithmetics.sin(x);
            return result;
        }

        [PexMethod]
        public bool sinImpossible(double x)
        {
            bool result = L1_Arithmetics.sinImpossible(x);
            return result;
        }

        [PexMethod]
        public bool sqrt(double x)
        {
            bool result = L1_Arithmetics.sqrt(x);
            return result;
        }

        [PexMethod]
        public bool sqrtImpossible(double x)
        {
            bool result = L1_Arithmetics.sqrtImpossible(x);
            return result;
        }

        [PexMethod]
        public bool tan(double x)
        {
            bool result = L1_Arithmetics.tan(x);
            return result;
        }
    }
}
