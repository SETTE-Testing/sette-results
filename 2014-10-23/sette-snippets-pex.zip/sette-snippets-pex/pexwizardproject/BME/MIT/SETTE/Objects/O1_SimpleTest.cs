// <copyright file="O1_SimpleTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Objects;
using BME.MIT.SETTE.Objects.Dependencies;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Objects
{
    [PexClass(typeof(O1_Simple))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class O1_SimpleTest
    {
        [PexMethod]
        public int fullCoverage(
            SimpleObject obj,
            int x1,
            int x2,
            int oc
        )
        {
            int result = O1_Simple.fullCoverage(obj, x1, x2, oc);
            return result;
        }

        [PexMethod]
        public int guessImpossibleObject(SimpleObject obj)
        {
            int result = O1_Simple.guessImpossibleObject(obj);
            return result;
        }

        [PexMethod]
        public int guessImpossibleOperationCount(SimpleObject obj, int oc)
        {
            int result = O1_Simple.guessImpossibleOperationCount(obj, oc);
            return result;
        }

        [PexMethod]
        public int guessImpossibleOperationCountParams(int oc)
        {
            int result = O1_Simple.guessImpossibleOperationCountParams(oc);
            return result;
        }

        [PexMethod]
        public int guessImpossibleResult(
            SimpleObject obj,
            int x1,
            int x2,
            int x3
        )
        {
            int result = O1_Simple.guessImpossibleResult(obj, x1, x2, x3);
            return result;
        }

        [PexMethod]
        public int guessImpossibleResultAndOperationCount(
            SimpleObject obj,
            int x,
            int oc
        )
        {
            int result = O1_Simple.guessImpossibleResultAndOperationCount(obj, x, oc);
            return result;
        }

        [PexMethod]
        public int guessImpossibleResultAndOperationCountParams(int x, int oc)
        {
            int result = O1_Simple.guessImpossibleResultAndOperationCountParams(x, oc);
            return result;
        }

        [PexMethod]
        public int guessImpossibleResultParams(
            int x1,
            int x2,
            int x3
        )
        {
            int result = O1_Simple.guessImpossibleResultParams(x1, x2, x3);
            return result;
        }

        [PexMethod]
        public int guessObject(SimpleObject obj)
        {
            int result = O1_Simple.guessObject(obj);
            return result;
        }

        [PexMethod]
        public int guessOperationCount(SimpleObject obj, int oc)
        {
            int result = O1_Simple.guessOperationCount(obj, oc);
            return result;
        }

        [PexMethod]
        public int guessOperationCountParams(int oc)
        {
            int result = O1_Simple.guessOperationCountParams(oc);
            return result;
        }

        [PexMethod]
        public int guessResult(
            SimpleObject obj,
            int x1,
            int x2,
            int x3
        )
        {
            int result = O1_Simple.guessResult(obj, x1, x2, x3);
            return result;
        }

        [PexMethod]
        public int guessResultAndOperationCount(
            SimpleObject obj,
            int x,
            int oc
        )
        {
            int result = O1_Simple.guessResultAndOperationCount(obj, x, oc);
            return result;
        }

        [PexMethod]
        public int guessResultAndOperationCountParams(int x, int oc)
        {
            int result = O1_Simple.guessResultAndOperationCountParams(x, oc);
            return result;
        }

        [PexMethod]
        public int guessResultParams(
            int x1,
            int x2,
            int x3
        )
        {
            int result = O1_Simple.guessResultParams(x1, x2, x3);
            return result;
        }

        [PexMethod]
        public int oneOperationNoCheck(SimpleObject obj, int x)
        {
            int result = O1_Simple.oneOperationNoCheck(obj, x);
            return result;
        }

        [PexMethod]
        public int oneOperationParams(int x)
        {
            int result = O1_Simple.oneOperationParams(x);
            return result;
        }

        [PexMethod]
        public int oneOperationWithCheck(SimpleObject obj, int x)
        {
            int result = O1_Simple.oneOperationWithCheck(obj, x);
            return result;
        }

        [PexMethod]
        public int twoOperationsParams(int x1, int x2)
        {
            int result = O1_Simple.twoOperationsParams(x1, x2);
            return result;
        }

        [PexMethod]
        public int twoOperationsWithCheck(
            SimpleObject obj,
            int x1,
            int x2
        )
        {
            int result = O1_Simple.twoOperationsWithCheck(obj, x1, x2);
            return result;
        }

        [PexMethod]
        public int twoOperationsWithNocheck(
            SimpleObject obj,
            int x1,
            int x2
        )
        {
            int result = O1_Simple.twoOperationsWithNocheck(obj, x1, x2);
            return result;
        }
    }
}
