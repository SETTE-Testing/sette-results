// <copyright file="O2_DelegateTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Objects;
using BME.MIT.SETTE.Objects.Dependencies;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Objects
{
    [PexClass(typeof(O2_Delegate))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class O2_DelegateTest
    {
        [PexMethod]
        public int guessResult(
            SimpleObjectDelegate obj,
            int x1,
            int x2,
            int x3
        )
        {
            int result = O2_Delegate.guessResult(obj, x1, x2, x3);
            return result;
        }

        [PexMethod]
        public int guessResultParams(
            int x1,
            int x2,
            int x3
        )
        {
            int result = O2_Delegate.guessResultParams(x1, x2, x3);
            return result;
        }
    }
}
