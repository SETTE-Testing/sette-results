// <copyright file="O3c_AbstractTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Objects;
using BME.MIT.SETTE.Objects.Dependencies;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Objects
{
    [PexClass(typeof(O3c_Abstract))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class O3c_AbstractTest
    {
        [PexMethod]
        public int guess(MyAbstract obj, int v)
        {
            int result = O3c_Abstract.guess(obj, v);
            return result;
        }

        [PexMethod]
        public int guessImpossible(MyAbstract obj, int v)
        {
            int result = O3c_Abstract.guessImpossible(obj, v);
            return result;
        }

        [PexMethod]
        public int validate(MyAbstract obj, int v)
        {
            int result = O3c_Abstract.validate(obj, v);
            return result;
        }
    }
}
