// <copyright file="O4_OverrideTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Objects;
using BME.MIT.SETTE.Objects.Dependencies;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Objects
{
    [PexClass(typeof(O4_Override))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class O4_OverrideTest
    {
        [PexMethod]
        public int guessImpossible(
            SimpleObjectOverride obj,
            int x1,
            int x2,
            int x3
        )
        {
            int result = O4_Override.guessImpossible(obj, x1, x2, x3);
            return result;
        }

        [PexMethod]
        public int guessImpossibleParams(
            int x1,
            int x2,
            int x3
        )
        {
            int result = O4_Override.guessImpossibleParams(x1, x2, x3);
            return result;
        }

        [PexMethod]
        public int guessResult(
            SimpleObjectOverride obj,
            int x1,
            int x2,
            int x3
        )
        {
            int result = O4_Override.guessResult(obj, x1, x2, x3);
            return result;
        }

        [PexMethod]
        public int guessResultParams(
            int x1,
            int x2,
            int x3
        )
        {
            int result = O4_Override.guessResultParams(x1, x2, x3);
            return result;
        }
    }
}
