// <copyright file="O3a_InheritanceTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Objects;
using BME.MIT.SETTE.Objects.Dependencies;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Objects
{
    [PexClass(typeof(O3a_Inheritance))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class O3a_InheritanceTest
    {
        [PexMethod]
        public int guessResult(
            SimpleExtendedObject obj,
            int x1,
            int x2,
            int x3
        )
        {
            int result = O3a_Inheritance.guessResult(obj, x1, x2, x3);
            return result;
        }

        [PexMethod]
        public int guessResultParams(
            int x1,
            int x2,
            int x3
        )
        {
            int result = O3a_Inheritance.guessResultParams(x1, x2, x3);
            return result;
        }
    }
}
