// <copyright file="O3b_InterfaceTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Objects;
using BME.MIT.SETTE.Objects.Dependencies;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Objects
{
    [PexClass(typeof(O3b_Interface))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class O3b_InterfaceTest
    {
        [PexMethod]
        public int guess(MyInterface obj, int v)
        {
            int result = O3b_Interface.guess(obj, v);
            return result;
        }

        [PexMethod]
        public int guessImpossible(MyInterface obj, int v)
        {
            int result = O3b_Interface.guessImpossible(obj, v);
            return result;
        }

        [PexMethod]
        public int validate(MyInterface obj, int v)
        {
            int result = O3b_Interface.validate(obj, v);
            return result;
        }
    }
}
