// <copyright file="VarargsTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Others;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Others
{
    [PexClass(typeof(Varargs))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class VarargsTest
    {
        [PexMethod]
        public int guess(int[] numbers)
        {
            int result = Varargs.guess(numbers);
            return result;
        }

        [PexMethod]
        public int guessWithLength(int[] numbers)
        {
            int result = Varargs.guessWithLength(numbers);
            return result;
        }

        [PexMethod]
        public int[] iterateWithFor(int[] numbers)
        {
            int[] result = Varargs.iterateWithFor(numbers);
            return result;
        }

        [PexMethod]
        public int[] iterateWithForeach(int[] numbers)
        {
            int[] result = Varargs.iterateWithForeach(numbers);
            return result;
        }
    }
}
