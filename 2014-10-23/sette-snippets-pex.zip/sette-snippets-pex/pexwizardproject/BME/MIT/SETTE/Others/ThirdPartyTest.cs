// <copyright file="ThirdPartyTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Others;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Others
{
    [PexClass(typeof(ThirdParty))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class ThirdPartyTest
    {
        [PexMethod]
        public bool minMax(int a, int b)
        {
            bool result = ThirdParty.minMax(a, b);
            return result;
        }

        [PexMethod]
        public bool minMaxImpossible(int a, int b)
        {
            bool result = ThirdParty.minMaxImpossible(a, b);
            return result;
        }

        [PexMethod]
        public bool minMaxWithOrder(int a, int b)
        {
            bool result = ThirdParty.minMaxWithOrder(a, b);
            return result;
        }
    }
}
