// <copyright file="EnumTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Others;
using BME.MIT.SETTE.Others.Dependencies;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Others
{
    [PexClass(typeof(Enum))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class EnumTest
    {
        [PexMethod]
        public int guessEnum(State s)
        {
            int result = Enum.guessEnum(s);
            return result;
        }

        [PexMethod]
        public int guessEnumOrdinal(State s)
        {
            int result = Enum.guessEnumOrdinal(s);
            return result;
        }

        [PexMethod]
        public int guessEnumString(State s)
        {
            int result = Enum.guessEnumString(s);
            return result;
        }

        [PexMethod]
        public int switchEnum(State s)
        {
            int result = Enum.switchEnum(s);
            return result;
        }
    }
}
