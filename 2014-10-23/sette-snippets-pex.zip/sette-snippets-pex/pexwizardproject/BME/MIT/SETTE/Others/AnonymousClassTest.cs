// <copyright file="AnonymousClassTest.cs">Copyright �  2014</copyright>
using System;
using BME.MIT.SETTE.Others;
using Microsoft.Pex.Framework;
using Microsoft.Pex.Framework.Validation;
using NUnit.Framework;

namespace BME.MIT.SETTE.Others
{
    [PexClass(typeof(AnonymousClass))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(InvalidOperationException))]
    [PexAllowedExceptionFromTypeUnderTest(typeof(ArgumentException), AcceptExceptionSubtypes = true)]
    [TestFixture]
    public partial class AnonymousClassTest
    {
        [PexMethod]
        public int test(int x)
        {
            int result = AnonymousClass.test(x);
            return result;
        }
    }
}
