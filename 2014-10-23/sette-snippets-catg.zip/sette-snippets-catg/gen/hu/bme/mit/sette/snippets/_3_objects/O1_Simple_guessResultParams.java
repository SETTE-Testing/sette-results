package hu.bme.mit.sette.snippets._3_objects;

import hu.bme.mit.sette.snippets._3_objects.O1_Simple;
import catg.CATG;

public final class O1_Simple_guessResultParams {
    public static void main(String[] args) throws Exception {
        int param1 = CATG.readInt(1);
        int param2 = CATG.readInt(1);
        int param3 = CATG.readInt(1);
        
        System.out.println("O1_Simple#guessResultParams");
        System.out.println("  int param1 = " + param1);
        System.out.println("  int param2 = " + param2);
        System.out.println("  int param3 = " + param3);
        System.out.println("  result: " + O1_Simple.guessResultParams(param1, param2, param3));
    }
}
