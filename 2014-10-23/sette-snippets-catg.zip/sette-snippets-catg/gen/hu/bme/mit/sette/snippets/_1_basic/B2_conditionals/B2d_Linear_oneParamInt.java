package hu.bme.mit.sette.snippets._1_basic.B2_conditionals;

import hu.bme.mit.sette.snippets._1_basic.B2_conditionals.B2d_Linear;
import catg.CATG;

public final class B2d_Linear_oneParamInt {
    public static void main(String[] args) throws Exception {
        int param1 = CATG.readInt(1);
        
        System.out.println("B2d_Linear#oneParamInt");
        System.out.println("  int param1 = " + param1);
        System.out.println("  result: " + B2d_Linear.oneParamInt(param1));
    }
}
