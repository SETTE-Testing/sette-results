package hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators;

import hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators.B1c_ArithmeticalOperators;
import catg.CATG;

public final class B1c_ArithmeticalOperators_postfixPlusplus {
    public static void main(String[] args) throws Exception {
        int param1 = CATG.readInt(1);
        
        System.out.println("B1c_ArithmeticalOperators#postfixPlusplus");
        System.out.println("  int param1 = " + param1);
        System.out.println("  result: " + B1c_ArithmeticalOperators.postfixPlusplus(param1));
    }
}
