package hu.bme.mit.sette.snippets._2_structures;

import hu.bme.mit.sette.snippets._2_structures.S4_StructureInStructure;
import catg.CATG;

public final class S4_StructureInStructure_guessParams {
    public static void main(String[] args) throws Exception {
        int param1 = CATG.readInt(1);
        int param2 = CATG.readInt(1);
        int param3 = CATG.readInt(1);
        int param4 = CATG.readInt(1);
        
        System.out.println("S4_StructureInStructure#guessParams");
        System.out.println("  int param1 = " + param1);
        System.out.println("  int param2 = " + param2);
        System.out.println("  int param3 = " + param3);
        System.out.println("  int param4 = " + param4);
        System.out.println("  result: " + S4_StructureInStructure.guessParams(param1, param2, param3, param4));
    }
}
