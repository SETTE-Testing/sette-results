package hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators;

import hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators.B1b_Constants;
import catg.CATG;

public final class B1b_Constants_constChar {
    public static void main(String[] args) throws Exception {
        
        System.out.println("B1b_Constants#constChar");
        System.out.println("  result: " + B1b_Constants.constChar());
    }
}
