package hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators;

import hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators.B1d_RelationalOperators;
import catg.CATG;

public final class B1d_RelationalOperators_and {
    public static void main(String[] args) throws Exception {
        boolean param1 = CATG.readBool(false);
        boolean param2 = CATG.readBool(false);
        
        System.out.println("B1d_RelationalOperators#and");
        System.out.println("  boolean param1 = " + param1);
        System.out.println("  boolean param2 = " + param2);
        System.out.println("  result: " + B1d_RelationalOperators.and(param1, param2));
    }
}
