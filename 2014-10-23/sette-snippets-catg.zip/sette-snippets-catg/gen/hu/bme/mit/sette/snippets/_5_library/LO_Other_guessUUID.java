package hu.bme.mit.sette.snippets._5_library;

import hu.bme.mit.sette.snippets._5_library.LO_Other;
import catg.CATG;

public final class LO_Other_guessUUID {
    public static void main(String[] args) throws Exception {
        String param1 = CATG.readString("");
        
        System.out.println("LO_Other#guessUUID");
        System.out.println("  String param1 = " + param1);
        System.out.println("  result: " + LO_Other.guessUUID(param1));
    }
}
