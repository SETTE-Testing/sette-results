package hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators;

import hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators.B1a_PrimitiveTypes;
import catg.CATG;

public final class B1a_PrimitiveTypes_oneParamByte {
    public static void main(String[] args) throws Exception {
        byte param1 = CATG.readByte((byte) 1);
        
        System.out.println("B1a_PrimitiveTypes#oneParamByte");
        System.out.println("  byte param1 = " + param1);
        System.out.println("  result: " + B1a_PrimitiveTypes.oneParamByte(param1));
    }
}
