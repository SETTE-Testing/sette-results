package hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators;

import hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators.B1a_PrimitiveTypes;
import catg.CATG;

public final class B1a_PrimitiveTypes_oneParamLong {
    public static void main(String[] args) throws Exception {
        long param1 = CATG.readLong(1L);
        
        System.out.println("B1a_PrimitiveTypes#oneParamLong");
        System.out.println("  long param1 = " + param1);
        System.out.println("  result: " + B1a_PrimitiveTypes.oneParamLong(param1));
    }
}
