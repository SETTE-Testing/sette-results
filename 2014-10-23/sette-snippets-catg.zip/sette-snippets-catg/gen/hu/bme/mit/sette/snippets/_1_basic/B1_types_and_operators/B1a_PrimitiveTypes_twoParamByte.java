package hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators;

import hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators.B1a_PrimitiveTypes;
import catg.CATG;

public final class B1a_PrimitiveTypes_twoParamByte {
    public static void main(String[] args) throws Exception {
        byte param1 = CATG.readByte((byte) 1);
        byte param2 = CATG.readByte((byte) 1);
        
        System.out.println("B1a_PrimitiveTypes#twoParamByte");
        System.out.println("  byte param1 = " + param1);
        System.out.println("  byte param2 = " + param2);
        System.out.println("  result: " + B1a_PrimitiveTypes.twoParamByte(param1, param2));
    }
}
