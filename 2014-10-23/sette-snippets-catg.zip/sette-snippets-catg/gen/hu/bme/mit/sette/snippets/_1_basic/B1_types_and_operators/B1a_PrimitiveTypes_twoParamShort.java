package hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators;

import hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators.B1a_PrimitiveTypes;
import catg.CATG;

public final class B1a_PrimitiveTypes_twoParamShort {
    public static void main(String[] args) throws Exception {
        short param1 = CATG.readShort((short) 1);
        short param2 = CATG.readShort((short) 1);
        
        System.out.println("B1a_PrimitiveTypes#twoParamShort");
        System.out.println("  short param1 = " + param1);
        System.out.println("  short param2 = " + param2);
        System.out.println("  result: " + B1a_PrimitiveTypes.twoParamShort(param1, param2));
    }
}
