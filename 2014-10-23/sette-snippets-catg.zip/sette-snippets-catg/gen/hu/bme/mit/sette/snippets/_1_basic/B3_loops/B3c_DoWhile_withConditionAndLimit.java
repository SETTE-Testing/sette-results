package hu.bme.mit.sette.snippets._1_basic.B3_loops;

import hu.bme.mit.sette.snippets._1_basic.B3_loops.B3c_DoWhile;
import catg.CATG;

public final class B3c_DoWhile_withConditionAndLimit {
    public static void main(String[] args) throws Exception {
        int param1 = CATG.readInt(1);
        
        System.out.println("B3c_DoWhile#withConditionAndLimit");
        System.out.println("  int param1 = " + param1);
        System.out.println("  result: " + B3c_DoWhile.withConditionAndLimit(param1));
    }
}
