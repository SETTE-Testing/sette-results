package hu.bme.mit.sette.snippets._2_structures;

import hu.bme.mit.sette.snippets._2_structures.S1_BasicUsage;
import catg.CATG;

public final class S1_BasicUsage_useStructureParams {
    public static void main(String[] args) throws Exception {
        int param1 = CATG.readInt(1);
        int param2 = CATG.readInt(1);
        
        System.out.println("S1_BasicUsage#useStructureParams");
        System.out.println("  int param1 = " + param1);
        System.out.println("  int param2 = " + param2);
        System.out.println("  result: " + S1_BasicUsage.useStructureParams(param1, param2));
    }
}
