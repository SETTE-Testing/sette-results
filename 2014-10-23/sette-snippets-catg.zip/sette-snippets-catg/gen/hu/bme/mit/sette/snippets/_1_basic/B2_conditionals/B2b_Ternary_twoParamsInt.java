package hu.bme.mit.sette.snippets._1_basic.B2_conditionals;

import hu.bme.mit.sette.snippets._1_basic.B2_conditionals.B2b_Ternary;
import catg.CATG;

public final class B2b_Ternary_twoParamsInt {
    public static void main(String[] args) throws Exception {
        int param1 = CATG.readInt(1);
        int param2 = CATG.readInt(1);
        
        System.out.println("B2b_Ternary#twoParamsInt");
        System.out.println("  int param1 = " + param1);
        System.out.println("  int param2 = " + param2);
        System.out.println("  result: " + B2b_Ternary.twoParamsInt(param1, param2));
    }
}
