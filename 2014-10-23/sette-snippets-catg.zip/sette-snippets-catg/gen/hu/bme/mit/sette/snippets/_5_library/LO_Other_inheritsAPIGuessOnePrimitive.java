package hu.bme.mit.sette.snippets._5_library;

import hu.bme.mit.sette.snippets._5_library.LO_Other;
import catg.CATG;

public final class LO_Other_inheritsAPIGuessOnePrimitive {
    public static void main(String[] args) throws Exception {
        int param1 = CATG.readInt(1);
        
        System.out.println("LO_Other#inheritsAPIGuessOnePrimitive");
        System.out.println("  int param1 = " + param1);
        System.out.println("  result: " + LO_Other.inheritsAPIGuessOnePrimitive(param1));
    }
}
