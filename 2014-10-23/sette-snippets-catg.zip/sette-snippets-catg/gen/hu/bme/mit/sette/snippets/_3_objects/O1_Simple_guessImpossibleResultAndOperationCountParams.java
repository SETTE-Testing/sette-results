package hu.bme.mit.sette.snippets._3_objects;

import hu.bme.mit.sette.snippets._3_objects.O1_Simple;
import catg.CATG;

public final class O1_Simple_guessImpossibleResultAndOperationCountParams {
    public static void main(String[] args) throws Exception {
        int param1 = CATG.readInt(1);
        int param2 = CATG.readInt(1);
        
        System.out.println("O1_Simple#guessImpossibleResultAndOperationCountParams");
        System.out.println("  int param1 = " + param1);
        System.out.println("  int param2 = " + param2);
        System.out.println("  result: " + O1_Simple.guessImpossibleResultAndOperationCountParams(param1, param2));
    }
}
