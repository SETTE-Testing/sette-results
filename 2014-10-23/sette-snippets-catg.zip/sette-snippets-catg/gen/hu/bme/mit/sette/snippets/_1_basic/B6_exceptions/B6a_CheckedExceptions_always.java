package hu.bme.mit.sette.snippets._1_basic.B6_exceptions;

import hu.bme.mit.sette.snippets._1_basic.B6_exceptions.B6a_CheckedExceptions;
import catg.CATG;

public final class B6a_CheckedExceptions_always {
    public static void main(String[] args) throws Exception {
        
        System.out.println("B6a_CheckedExceptions#always");
        B6a_CheckedExceptions.always();
        System.out.println("  result: void");
    }
}
