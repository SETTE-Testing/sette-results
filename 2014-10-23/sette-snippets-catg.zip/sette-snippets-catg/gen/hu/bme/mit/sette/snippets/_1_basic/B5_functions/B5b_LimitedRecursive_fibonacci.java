package hu.bme.mit.sette.snippets._1_basic.B5_functions;

import hu.bme.mit.sette.snippets._1_basic.B5_functions.B5b_LimitedRecursive;
import catg.CATG;

public final class B5b_LimitedRecursive_fibonacci {
    public static void main(String[] args) throws Exception {
        int param1 = CATG.readInt(1);
        
        System.out.println("B5b_LimitedRecursive#fibonacci");
        System.out.println("  int param1 = " + param1);
        System.out.println("  result: " + B5b_LimitedRecursive.fibonacci(param1));
    }
}
