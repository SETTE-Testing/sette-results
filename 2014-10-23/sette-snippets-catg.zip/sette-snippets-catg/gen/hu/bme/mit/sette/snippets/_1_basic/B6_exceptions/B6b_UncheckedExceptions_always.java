package hu.bme.mit.sette.snippets._1_basic.B6_exceptions;

import hu.bme.mit.sette.snippets._1_basic.B6_exceptions.B6b_UncheckedExceptions;
import catg.CATG;

public final class B6b_UncheckedExceptions_always {
    public static void main(String[] args) throws Exception {
        
        System.out.println("B6b_UncheckedExceptions#always");
        B6b_UncheckedExceptions.always();
        System.out.println("  result: void");
    }
}
