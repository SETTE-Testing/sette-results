package hu.bme.mit.sette.snippets._1_basic.B3_loops;

import hu.bme.mit.sette.snippets._1_basic.B3_loops.B3b_For;
import catg.CATG;

public final class B3b_For_withLimit {
    public static void main(String[] args) throws Exception {
        int param1 = CATG.readInt(1);
        
        System.out.println("B3b_For#withLimit");
        System.out.println("  int param1 = " + param1);
        System.out.println("  result: " + B3b_For.withLimit(param1));
    }
}
