package hu.bme.mit.sette.snippets._1_basic.B6_exceptions;

import hu.bme.mit.sette.snippets._1_basic.B6_exceptions.B6a_CheckedExceptions;
import catg.CATG;

public final class B6a_CheckedExceptions_tryCatch {
    public static void main(String[] args) throws Exception {
        int param1 = CATG.readInt(1);
        int param2 = CATG.readInt(1);
        
        System.out.println("B6a_CheckedExceptions#tryCatch");
        System.out.println("  int param1 = " + param1);
        System.out.println("  int param2 = " + param2);
        System.out.println("  result: " + B6a_CheckedExceptions.tryCatch(param1, param2));
    }
}
