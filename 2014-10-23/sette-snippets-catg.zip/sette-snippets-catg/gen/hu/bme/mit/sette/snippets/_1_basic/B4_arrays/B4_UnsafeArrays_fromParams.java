package hu.bme.mit.sette.snippets._1_basic.B4_arrays;

import hu.bme.mit.sette.snippets._1_basic.B4_arrays.B4_UnsafeArrays;
import catg.CATG;

public final class B4_UnsafeArrays_fromParams {
    public static void main(String[] args) throws Exception {
        int param1 = CATG.readInt(1);
        int param2 = CATG.readInt(1);
        int param3 = CATG.readInt(1);
        
        System.out.println("B4_UnsafeArrays#fromParams");
        System.out.println("  int param1 = " + param1);
        System.out.println("  int param2 = " + param2);
        System.out.println("  int param3 = " + param3);
        System.out.println("  result: " + B4_UnsafeArrays.fromParams(param1, param2, param3));
    }
}
