package hu.bme.mit.sette.snippets._6_others;

import hu.bme.mit.sette.snippets._6_others.ThirdParty;
import catg.CATG;

public final class ThirdParty_minMaxWithOrder {
    public static void main(String[] args) throws Exception {
        int param1 = CATG.readInt(1);
        int param2 = CATG.readInt(1);
        
        System.out.println("ThirdParty#minMaxWithOrder");
        System.out.println("  int param1 = " + param1);
        System.out.println("  int param2 = " + param2);
        System.out.println("  result: " + ThirdParty.minMaxWithOrder(param1, param2));
    }
}
