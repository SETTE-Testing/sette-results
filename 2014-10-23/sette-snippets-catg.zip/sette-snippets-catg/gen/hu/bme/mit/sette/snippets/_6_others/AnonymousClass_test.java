package hu.bme.mit.sette.snippets._6_others;

import hu.bme.mit.sette.snippets._6_others.AnonymousClass;
import catg.CATG;

public final class AnonymousClass_test {
    public static void main(String[] args) throws Exception {
        int param1 = CATG.readInt(1);
        
        System.out.println("AnonymousClass#test");
        System.out.println("  int param1 = " + param1);
        System.out.println("  result: " + AnonymousClass.test(param1));
    }
}
