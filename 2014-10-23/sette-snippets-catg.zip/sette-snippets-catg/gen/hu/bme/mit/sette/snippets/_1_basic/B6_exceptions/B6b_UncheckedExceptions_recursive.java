package hu.bme.mit.sette.snippets._1_basic.B6_exceptions;

import hu.bme.mit.sette.snippets._1_basic.B6_exceptions.B6b_UncheckedExceptions;
import catg.CATG;

public final class B6b_UncheckedExceptions_recursive {
    public static void main(String[] args) throws Exception {
        int param1 = CATG.readInt(1);
        
        System.out.println("B6b_UncheckedExceptions#recursive");
        System.out.println("  int param1 = " + param1);
        System.out.println("  result: " + B6b_UncheckedExceptions.recursive(param1));
    }
}
