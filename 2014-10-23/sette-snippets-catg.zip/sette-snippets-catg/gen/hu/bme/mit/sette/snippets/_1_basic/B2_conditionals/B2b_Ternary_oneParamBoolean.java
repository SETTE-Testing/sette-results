package hu.bme.mit.sette.snippets._1_basic.B2_conditionals;

import hu.bme.mit.sette.snippets._1_basic.B2_conditionals.B2b_Ternary;
import catg.CATG;

public final class B2b_Ternary_oneParamBoolean {
    public static void main(String[] args) throws Exception {
        boolean param1 = CATG.readBool(false);
        
        System.out.println("B2b_Ternary#oneParamBoolean");
        System.out.println("  boolean param1 = " + param1);
        System.out.println("  result: " + B2b_Ternary.oneParamBoolean(param1));
    }
}
