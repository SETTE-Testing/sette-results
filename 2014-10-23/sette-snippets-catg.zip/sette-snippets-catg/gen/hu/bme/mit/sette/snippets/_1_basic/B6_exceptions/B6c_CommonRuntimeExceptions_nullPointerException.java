package hu.bme.mit.sette.snippets._1_basic.B6_exceptions;

import hu.bme.mit.sette.snippets._1_basic.B6_exceptions.B6c_CommonRuntimeExceptions;
import catg.CATG;

public final class B6c_CommonRuntimeExceptions_nullPointerException {
    public static void main(String[] args) throws Exception {
        boolean param1 = CATG.readBool(false);
        
        System.out.println("B6c_CommonRuntimeExceptions#nullPointerException");
        System.out.println("  boolean param1 = " + param1);
        System.out.println("  result: " + B6c_CommonRuntimeExceptions.nullPointerException(param1));
    }
}
