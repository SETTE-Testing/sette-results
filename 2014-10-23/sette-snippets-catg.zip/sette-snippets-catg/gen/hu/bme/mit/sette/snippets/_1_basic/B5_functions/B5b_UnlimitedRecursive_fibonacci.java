package hu.bme.mit.sette.snippets._1_basic.B5_functions;

import hu.bme.mit.sette.snippets._1_basic.B5_functions.B5b_UnlimitedRecursive;
import catg.CATG;

public final class B5b_UnlimitedRecursive_fibonacci {
    public static void main(String[] args) throws Exception {
        int param1 = CATG.readInt(1);
        
        System.out.println("B5b_UnlimitedRecursive#fibonacci");
        System.out.println("  int param1 = " + param1);
        System.out.println("  result: " + B5b_UnlimitedRecursive.fibonacci(param1));
    }
}
