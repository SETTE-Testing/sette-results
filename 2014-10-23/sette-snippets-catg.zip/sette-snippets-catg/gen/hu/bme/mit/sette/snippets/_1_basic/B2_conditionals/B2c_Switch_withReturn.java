package hu.bme.mit.sette.snippets._1_basic.B2_conditionals;

import hu.bme.mit.sette.snippets._1_basic.B2_conditionals.B2c_Switch;
import catg.CATG;

public final class B2c_Switch_withReturn {
    public static void main(String[] args) throws Exception {
        int param1 = CATG.readInt(1);
        
        System.out.println("B2c_Switch#withReturn");
        System.out.println("  int param1 = " + param1);
        System.out.println("  result: " + B2c_Switch.withReturn(param1));
    }
}
