package hu.bme.mit.sette.snippets._5_library;

import hu.bme.mit.sette.snippets._5_library.L3_Wrappers;
import catg.CATG;

public final class L3_Wrappers_integerOverflow {
    public static void main(String[] args) throws Exception {
        int param1 = CATG.readInt(1);
        int param2 = CATG.readInt(1);
        
        System.out.println("L3_Wrappers#integerOverflow");
        System.out.println("  int param1 = " + param1);
        System.out.println("  int param2 = " + param2);
        System.out.println("  result: " + L3_Wrappers.integerOverflow(param1, param2));
    }
}
