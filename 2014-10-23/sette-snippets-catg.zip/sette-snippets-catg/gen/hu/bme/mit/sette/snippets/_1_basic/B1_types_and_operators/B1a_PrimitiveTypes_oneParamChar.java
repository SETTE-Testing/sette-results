package hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators;

import hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators.B1a_PrimitiveTypes;
import catg.CATG;

public final class B1a_PrimitiveTypes_oneParamChar {
    public static void main(String[] args) throws Exception {
        char param1 = CATG.readChar(' ');
        
        System.out.println("B1a_PrimitiveTypes#oneParamChar");
        System.out.println("  char param1 = " + param1);
        System.out.println("  result: " + B1a_PrimitiveTypes.oneParamChar(param1));
    }
}
