package hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators;

import hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators.B1e_BitwiseOperators;
import catg.CATG;

public final class B1e_BitwiseOperators_xorAssignment {
    public static void main(String[] args) throws Exception {
        int param1 = CATG.readInt(1);
        int param2 = CATG.readInt(1);
        
        System.out.println("B1e_BitwiseOperators#xorAssignment");
        System.out.println("  int param1 = " + param1);
        System.out.println("  int param2 = " + param2);
        System.out.println("  result: " + B1e_BitwiseOperators.xorAssignment(param1, param2));
    }
}
