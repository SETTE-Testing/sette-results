package hu.bme.mit.sette.snippets._1_basic.B3_loops;

import hu.bme.mit.sette.snippets._1_basic.B3_loops.B3a_While;
import catg.CATG;

public final class B3a_While_withContinueBreak {
    public static void main(String[] args) throws Exception {
        int param1 = CATG.readInt(1);
        
        System.out.println("B3a_While#withContinueBreak");
        System.out.println("  int param1 = " + param1);
        System.out.println("  result: " + B3a_While.withContinueBreak(param1));
    }
}
