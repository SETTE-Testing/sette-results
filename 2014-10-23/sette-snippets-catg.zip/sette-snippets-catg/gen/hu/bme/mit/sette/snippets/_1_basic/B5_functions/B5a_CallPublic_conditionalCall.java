package hu.bme.mit.sette.snippets._1_basic.B5_functions;

import hu.bme.mit.sette.snippets._1_basic.B5_functions.B5a_CallPublic;
import catg.CATG;

public final class B5a_CallPublic_conditionalCall {
    public static void main(String[] args) throws Exception {
        int param1 = CATG.readInt(1);
        int param2 = CATG.readInt(1);
        boolean param3 = CATG.readBool(false);
        
        System.out.println("B5a_CallPublic#conditionalCall");
        System.out.println("  int param1 = " + param1);
        System.out.println("  int param2 = " + param2);
        System.out.println("  boolean param3 = " + param3);
        System.out.println("  result: " + B5a_CallPublic.conditionalCall(param1, param2, param3));
    }
}
