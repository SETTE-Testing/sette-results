package hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators;

import hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators.B1d_RelationalOperators;
import catg.CATG;

public final class B1d_RelationalOperators_smallerOrEqual {
    public static void main(String[] args) throws Exception {
        int param1 = CATG.readInt(1);
        int param2 = CATG.readInt(1);
        
        System.out.println("B1d_RelationalOperators#smallerOrEqual");
        System.out.println("  int param1 = " + param1);
        System.out.println("  int param2 = " + param2);
        System.out.println("  result: " + B1d_RelationalOperators.smallerOrEqual(param1, param2));
    }
}
