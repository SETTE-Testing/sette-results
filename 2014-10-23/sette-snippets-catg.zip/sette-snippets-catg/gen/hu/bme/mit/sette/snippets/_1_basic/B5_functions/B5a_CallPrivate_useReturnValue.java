package hu.bme.mit.sette.snippets._1_basic.B5_functions;

import hu.bme.mit.sette.snippets._1_basic.B5_functions.B5a_CallPrivate;
import catg.CATG;

public final class B5a_CallPrivate_useReturnValue {
    public static void main(String[] args) throws Exception {
        int param1 = CATG.readInt(1);
        int param2 = CATG.readInt(1);
        
        System.out.println("B5a_CallPrivate#useReturnValue");
        System.out.println("  int param1 = " + param1);
        System.out.println("  int param2 = " + param2);
        System.out.println("  result: " + B5a_CallPrivate.useReturnValue(param1, param2));
    }
}
