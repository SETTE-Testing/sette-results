package hu.bme.mit.sette.snippets._5_library;

import hu.bme.mit.sette.snippets._5_library.L1_Arithmetics;
import catg.CATG;

public final class L1_Arithmetics_absImpossible {
    public static void main(String[] args) throws Exception {
        int param1 = CATG.readInt(1);
        int param2 = CATG.readInt(1);
        
        System.out.println("L1_Arithmetics#absImpossible");
        System.out.println("  int param1 = " + param1);
        System.out.println("  int param2 = " + param2);
        System.out.println("  result: " + L1_Arithmetics.absImpossible(param1, param2));
    }
}
