package hu.bme.mit.sette.snippets._5_library;

import hu.bme.mit.sette.snippets._5_library.L2_Strings;
import catg.CATG;

public final class L2_Strings_regionEquality {
    public static void main(String[] args) throws Exception {
        String param1 = CATG.readString("");
        
        System.out.println("L2_Strings#regionEquality");
        System.out.println("  String param1 = " + param1);
        System.out.println("  result: " + L2_Strings.regionEquality(param1));
    }
}
