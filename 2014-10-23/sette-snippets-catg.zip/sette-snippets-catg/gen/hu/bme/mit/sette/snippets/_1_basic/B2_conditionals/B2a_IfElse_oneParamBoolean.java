package hu.bme.mit.sette.snippets._1_basic.B2_conditionals;

import hu.bme.mit.sette.snippets._1_basic.B2_conditionals.B2a_IfElse;
import catg.CATG;

public final class B2a_IfElse_oneParamBoolean {
    public static void main(String[] args) throws Exception {
        boolean param1 = CATG.readBool(false);
        
        System.out.println("B2a_IfElse#oneParamBoolean");
        System.out.println("  boolean param1 = " + param1);
        System.out.println("  result: " + B2a_IfElse.oneParamBoolean(param1));
    }
}
