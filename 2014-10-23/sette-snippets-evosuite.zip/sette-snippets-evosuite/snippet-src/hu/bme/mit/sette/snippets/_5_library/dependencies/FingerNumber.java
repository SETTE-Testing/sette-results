package hu.bme.mit.sette.snippets._5_library.dependencies;


/**
 * Simple class implementing the Number interface. This class can only represent
 * between 1 to 10.
 */
public final class FingerNumber extends Number {

    private static final long serialVersionUID = 4280286901518300224L;

    private final int value;

    public FingerNumber(int v) {
        if (0 > v || v > 10) {
            throw new IllegalArgumentException();
        }
        value = v;
    }

    public FingerNumber add(FingerNumber o) {
        int r = value + o.value;
        if (r > 10) {
            throw new RuntimeException("Out of range");
        }
        return new FingerNumber(r);
    }

    @Override
    public int intValue() {
        return value;
    }

    @Override
    public long longValue() {
        return value;
    }

    @Override
    public float floatValue() {
        return value;
    }

    @Override
    public double doubleValue() {
        return value;
    }
}
