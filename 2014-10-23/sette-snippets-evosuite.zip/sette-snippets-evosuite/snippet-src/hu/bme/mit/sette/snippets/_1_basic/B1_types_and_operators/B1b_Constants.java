package hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators;


public final class B1b_Constants {

    private B1b_Constants() {
        throw new UnsupportedOperationException("Static class");
    }

    public static final boolean CONST_BOOLEAN = true;

    public static final byte CONST_BYTE = 123;

    public static final short CONST_SHORT = 12345;

    public static final int CONST_INT = 1234567890;

    public static final long CONST_LONG = 1234567890123456789L;

    public static final float CONST_FLOAT = 12345.67890f;

    public static final double CONST_DOUBLE = 1.2345678e90;

    public static final char CONST_CHAR = 'C';

    public static boolean constBoolean() {
        return B1b_Constants.CONST_BOOLEAN;
    }

    public static byte constByte() {
        return B1b_Constants.CONST_BYTE;
    }

    public static short constShort() {
        return B1b_Constants.CONST_SHORT;
    }

    public static int constInt() {
        return B1b_Constants.CONST_INT;
    }

    public static long constLong() {
        return B1b_Constants.CONST_LONG;
    }

    public static float constFloat() {
        return B1b_Constants.CONST_FLOAT;
    }

    public static double constDouble() {
        return B1b_Constants.CONST_DOUBLE;
    }

    public static char constChar() {
        return B1b_Constants.CONST_CHAR;
    }
}
