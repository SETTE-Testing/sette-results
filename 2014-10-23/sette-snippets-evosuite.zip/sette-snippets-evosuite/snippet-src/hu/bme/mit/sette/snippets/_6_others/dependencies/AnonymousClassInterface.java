package hu.bme.mit.sette.snippets._6_others.dependencies;


/**
 * Interface for anonymous class.
 */
public interface AnonymousClassInterface {

    int method(int x);
}
