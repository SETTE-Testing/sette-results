package hu.bme.mit.sette.snippets._6_others;


public final class Varargs {

    private Varargs() {
        throw new UnsupportedOperationException("Static class");
    }

    public static int guess(int... numbers) {
        if (numbers == null || numbers.length < 2) {
            return -1;
        }
        if (numbers[0] == 1 && numbers[1] == 2) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int guessWithLength(int... numbers) {
        if (numbers == null) {
            return -1;
        }
        if (numbers.length == 3 && numbers[0] == 1 && numbers[1] == 2) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int[] iterateWithFor(int... numbers) {
        if (numbers == null) {
            return new int[0];
        } else if (numbers.length > 3) {
            return new int[0];
        }
        int[] ret = new int[numbers.length];
        for (int i = 0; i < numbers.length; i++) {
            if (numbers[i] > 0) {
                ret[i] = 1;
            }
        }
        return numbers;
    }

    public static int[] iterateWithForeach(int... numbers) {
        if (numbers == null) {
            return new int[0];
        } else if (numbers.length > 3) {
            return new int[0];
        }
        int[] ret = new int[numbers.length];
        int i = 0;
        for (int n : numbers) {
            if (n > 0) {
                ret[i] = 1;
            }
            i++;
        }
        return numbers;
    }
}
