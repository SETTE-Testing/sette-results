package hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators;


public final class B1a_PrimitiveTypes {

    private B1a_PrimitiveTypes() {
        throw new UnsupportedOperationException("Static class");
    }

    public static boolean oneParamBoolean(boolean x) {
        return !x;
    }

    public static boolean twoParamBoolean(boolean x, boolean y) {
        return x ^ y;
    }

    public static byte oneParamByte(byte x) {
        return (byte) (x + 1);
    }

    public static byte twoParamByte(byte x, byte y) {
        return (byte) (x + y);
    }

    public static short oneParamShort(short x) {
        return (short) (x + 1);
    }

    public static short twoParamShort(short x, short y) {
        return (short) (x + y);
    }

    public static int oneParamInt(int x) {
        return x + 1;
    }

    public static int twoParamInt(int x, int y) {
        return x + y;
    }

    public static long oneParamLong(long x) {
        return x + 1;
    }

    public static long twoParamLong(long x, long y) {
        return x + y;
    }

    public static float oneParamFloat(float x) {
        return x + 1;
    }

    public static float twoParamFloat(float x, float y) {
        return x + y;
    }

    public static double oneParamDouble(double x) {
        return x + 1;
    }

    public static double twoParamDouble(double x, double y) {
        return x + y;
    }

    public static char oneParamChar(char x) {
        return (char) (x + 1);
    }

    public static char twoParamChar(char x, char y) {
        return (char) (x + y);
    }
}
