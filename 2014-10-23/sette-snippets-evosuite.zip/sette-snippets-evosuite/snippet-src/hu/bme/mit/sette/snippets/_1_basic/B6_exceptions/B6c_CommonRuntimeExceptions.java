package hu.bme.mit.sette.snippets._1_basic.B6_exceptions;


public final class B6c_CommonRuntimeExceptions {

    private B6c_CommonRuntimeExceptions() {
        throw new UnsupportedOperationException("Static class");
    }

    public static int arithmeticException(boolean b) {
        if (b) {
            throw new ArithmeticException();
        }
        return 1;
    }

    public static int arrayIndexOutOfBoundsException(boolean b) {
        if (b) {
            throw new ArrayIndexOutOfBoundsException();
        }
        return 1;
    }

    public static int classCastException(boolean b) {
        if (b) {
            throw new ClassCastException();
        }
        return 1;
    }

    public static int illegalArgumentException(boolean b) {
        if (b) {
            throw new IllegalArgumentException();
        }
        return 1;
    }

    public static int illegalStateException(boolean b) {
        if (b) {
            throw new IllegalStateException();
        }
        return 1;
    }

    public static int indexOutOfBoundsException(boolean b) {
        if (b) {
            throw new IndexOutOfBoundsException();
        }
        return 1;
    }

    public static int nullPointerException(boolean b) {
        if (b) {
            throw new NullPointerException();
        }
        return 1;
    }

    public static int securityException(boolean b) {
        if (b) {
            throw new SecurityException();
        }
        return 1;
    }

    public static int unsupportedOperationException(boolean b) {
        if (b) {
            throw new UnsupportedOperationException();
        }
        return 1;
    }
}
