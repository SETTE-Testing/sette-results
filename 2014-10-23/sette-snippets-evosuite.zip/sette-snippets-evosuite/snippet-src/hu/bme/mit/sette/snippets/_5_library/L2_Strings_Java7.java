package hu.bme.mit.sette.snippets._5_library;


public final class L2_Strings_Java7 {

    private L2_Strings_Java7() {
        throw new UnsupportedOperationException("Static class");
    }

    public static int switchString(String s) {
        if (s == null) {
            return -1;
        }
        switch(s) {
            case "case1":
                return 1;
            case "case2":
                return 2;
            default:
                return 0;
        }
    }
}
