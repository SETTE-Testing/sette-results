package hu.bme.mit.sette.snippets._2_structures;

import hu.bme.mit.sette.snippets._2_structures.dependencies.CoordinateStructure;

public final class S2_WithConditionals {

    private S2_WithConditionals() {
        throw new UnsupportedOperationException("Static class");
    }

    public static int oneStructureParams(int x, int y) {
        CoordinateStructure c = new CoordinateStructure();
        c.x = x;
        c.y = y;
        if (c.x > 0 && c.y > 0) {
            return 1;
        } else if (c.x < 0 && c.y > 0) {
            return 2;
        } else if (c.x < 0 && c.y < 0) {
            return 3;
        } else if (c.x > 0 && c.y < 0) {
            return 4;
        } else {
            return -1;
        }
    }

    public static int oneStructure(CoordinateStructure c) {
        if (c == null) {
            return 0;
        }
        if (c.x > 0 && c.y > 0) {
            return 1;
        } else if (c.x < 0 && c.y > 0) {
            return 2;
        } else if (c.x < 0 && c.y < 0) {
            return 3;
        } else if (c.x > 0 && c.y < 0) {
            return 4;
        } else {
            return -1;
        }
    }

    public static int twoStructuresParams(int x1, int y1, int x2, int y2) {
        CoordinateStructure c1 = new CoordinateStructure();
        c1.x = x1;
        c1.y = y1;
        CoordinateStructure c2 = new CoordinateStructure();
        c2.x = x2;
        c2.y = y2;
        CoordinateStructure c = new CoordinateStructure();
        c.x = c1.x + c2.x;
        c.y = c1.y + c2.y;
        if (c.x > 0 && c.y > 0) {
            return 1;
        } else if (c.x < 0 && c.y > 0) {
            return 2;
        } else if (c.x < 0 && c.y < 0) {
            return 3;
        } else if (c.x > 0 && c.y < 0) {
            return 4;
        } else {
            return -1;
        }
    }

    public static int twoStructures(CoordinateStructure c1, CoordinateStructure c2) {
        if (c1 == null || c2 == null) {
            return 0;
        }
        CoordinateStructure c = new CoordinateStructure();
        c.x = c1.x + c2.x;
        c.y = c1.y + c2.y;
        if (c.x > 0 && c.y > 0) {
            return 1;
        } else if (c.x < 0 && c.y > 0) {
            return 2;
        } else if (c.x < 0 && c.y < 0) {
            return 3;
        } else if (c.x > 0 && c.y < 0) {
            return 4;
        } else {
            return -1;
        }
    }
}
