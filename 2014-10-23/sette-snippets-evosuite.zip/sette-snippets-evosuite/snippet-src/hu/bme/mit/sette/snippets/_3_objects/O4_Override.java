package hu.bme.mit.sette.snippets._3_objects;

import hu.bme.mit.sette.snippets._3_objects.dependencies.SimpleObject;
import hu.bme.mit.sette.snippets._3_objects.dependencies.SimpleObjectOverride;

public final class O4_Override {

    private O4_Override() {
        throw new UnsupportedOperationException("Static class");
    }

    public static int guessResultParams(int x1, int x2, int x3) {
        SimpleObjectOverride obj = new SimpleObjectOverride();
        obj.addAbs(x1);
        obj.addAbs(x2);
        obj.addAbs(x3);
        if (obj.getResult() == 10) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int guessResult(SimpleObjectOverride obj, int x1, int x2, int x3) {
        if (obj == null) {
            return -1;
        }
        obj.addAbs(x1);
        obj.addAbs(x2);
        obj.addAbs(x3);
        if (obj.getResult() == 10) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int guessImpossibleParams(int x1, int x2, int x3) {
        SimpleObjectOverride obj = new SimpleObjectOverride();
        obj.addAbs(x1);
        obj.addAbs(x2);
        obj.addAbs(x3);
        if (obj.getResult() < 0) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int guessImpossible(SimpleObjectOverride obj, int x1, int x2, int x3) {
        if (obj == null) {
            return -1;
        }
        obj.addAbs(x1);
        obj.addAbs(x2);
        obj.addAbs(x3);
        if (obj.getResult() < 0) {
            return 1;
        } else {
            return 0;
        }
    }
}
