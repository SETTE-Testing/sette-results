package hu.bme.mit.sette.snippets._3_objects.dependencies;


/**
 * The delegate object type used by the code snippets O2.
 */
public class SimpleObjectDelegate {

    private final SimpleObject simpleObject;

    public SimpleObjectDelegate(SimpleObject so) {
        simpleObject = so;
    }

    public void addAbs(int x) {
        simpleObject.addAbs(x);
    }

    public int getResult() {
        return simpleObject.getResult();
    }
}
