package hu.bme.mit.sette.snippets._6_others;

import hu.bme.mit.sette.snippets.externals.MyMath;

public final class ThirdParty {

    private ThirdParty() {
        throw new UnsupportedOperationException("Static class");
    }

    public static boolean minMax(int a, int b) {
        if (MyMath.min(a, b) == -10 && MyMath.max(a, b) == 20) {
            return true;
        } else {
            return false;
        }
    }

    public static boolean minMaxWithOrder(int a, int b) {
        if (MyMath.min(a, b) == -10 && MyMath.max(a, b) == 20 && a < b) {
            return true;
        } else {
            return false;
        }
    }

    public static boolean minMaxImpossible(int a, int b) {
        if (MyMath.min(a, b) == -10 && MyMath.max(a, b) == 10 && Math.max(a, b) == 20) {
            throw new RuntimeException();
        } else {
            return false;
        }
    }
}
