package hu.bme.mit.sette.snippets._1_basic.B4_arrays;


/**
 * Safe arrays: using safe operations, i.e. IndexOutOfBoundsException and
 * NullPointerException cannot occur.<br/>
 * Unsafe arrays: not ensuring safe operations, i.e. IndexOutOfBoundsException
 * and NullPointerException may occur.
 */
public final class B4_UnsafeArrays {

    private B4_UnsafeArrays() {
        throw new UnsupportedOperationException("Static class");
    }

    public static int fromParams(int x, int y, int z) {
        int[] numbers = new int[] { x, y, z };
        if (numbers[0] == 1 && numbers[1] == 2 && numbers[2] == 3) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int indexParam(int index) {
        int[] numbers = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        if (numbers[index] == 5) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int guessLength(int length) {
        int[] numbers = new int[10];
        if (numbers.length == length) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int fromParamsWithIndex(int x, int y, int z, int index) {
        int[] numbers = new int[] { x, y, z };
        if (numbers[0] == 1 && numbers[1] == 2 && numbers[index] == 3) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int guessOneArray(int[] numbers) {
        if (numbers[0] == 1 && numbers[1] == 2) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int guessOneArrayWithLength(int[] numbers) {
        if (numbers.length == 3 && numbers[0] == 1 && numbers[1] == 2) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int twoArrays(int[] numbers1, int[] numbers2) {
        if (numbers1[0] + numbers2[0] == 1) {
            if (numbers2[1] == 2) {
                return 2;
            } else {
                return 1;
            }
        } else {
            return 0;
        }
    }

    public static int[] iterateWithFor(int[] numbers) {
        if (numbers.length > 3) {
            return new int[0];
        }
        int[] ret = new int[numbers.length];
        for (int i = 0; i < numbers.length; i++) {
            if (numbers[i] > 0) {
                ret[i] = 1;
            }
        }
        return numbers;
    }

    public static int[] iterateWithForeach(int[] numbers) {
        if (numbers.length > 3) {
            return new int[0];
        }
        int[] ret = new int[numbers.length];
        int i = 0;
        for (int n : numbers) {
            if (n > 0) {
                ret[i] = 1;
            }
            i++;
        }
        return numbers;
    }
}
