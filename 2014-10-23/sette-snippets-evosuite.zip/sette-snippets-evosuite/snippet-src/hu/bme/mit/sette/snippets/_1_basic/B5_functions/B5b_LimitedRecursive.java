package hu.bme.mit.sette.snippets._1_basic.B5_functions;


public final class B5b_LimitedRecursive {

    private B5b_LimitedRecursive() {
        throw new UnsupportedOperationException("Static class");
    }

    public static int simple(int x) {
        return simple_(x, 1);
    }

    private static int simple_(int x, int depth) {
        if (depth > 10) {
            return -1;
        }
        if (x % 100 == 0) {
            return x;
        } else {
            return simple_(x - 1, depth + 1);
        }
    }

    public static int fibonacci(int x) {
        return fibonacci_(x, 1);
    }

    private static int fibonacci_(int x, int depth) {
        if (depth > 10) {
            return 0;
        }
        if (x <= 0) {
            return 0;
        } else if (x == 1) {
            return 1;
        } else {
            return fibonacci_(x - 1, depth + 1) + fibonacci_(x - 2, depth + 2);
        }
    }
}
