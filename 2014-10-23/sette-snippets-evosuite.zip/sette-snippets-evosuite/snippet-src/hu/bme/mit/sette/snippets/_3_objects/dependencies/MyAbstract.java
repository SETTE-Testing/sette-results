package hu.bme.mit.sette.snippets._3_objects.dependencies;


/**
 * Half-implementation of the value setter-getter interface. Used by the code
 * snippets in O3.
 */
public abstract class MyAbstract implements MyInterface {

    @Override
    public MyAbstract chainedSetValue(int v) {
        setValue(v);
        return this;
    }
}
