package hu.bme.mit.sette.snippets._4_generics.dependencies;


/**
 * A generic collection used by the code snippets. This collection holds exactly
 * 3 integers.
 */
public class IntegerTriplet extends GenericTriplet<Integer> {

    public IntegerTriplet(Integer item1, Integer item2, Integer item3) {
        super(item1, item2, item3);
    }
}
