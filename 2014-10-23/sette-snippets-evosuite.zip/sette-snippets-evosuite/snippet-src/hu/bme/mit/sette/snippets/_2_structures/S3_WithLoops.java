package hu.bme.mit.sette.snippets._2_structures;

import hu.bme.mit.sette.snippets._2_structures.dependencies.CoordinateStructure;

public final class S3_WithLoops {

    private S3_WithLoops() {
        throw new UnsupportedOperationException("Static class");
    }

    public static int withLimitParams(int x, int y, int max) {
        CoordinateStructure c = new CoordinateStructure();
        c.x = x;
        c.y = y;
        int ret = 0;
        for (int i = 0; i < max && i < 10; i++) {
            if ((c.x + c.y) % 2 == 0) {
                ret++;
            } else {
                ret--;
            }
        }
        return ret;
    }

    public static int withLimit(CoordinateStructure c, int max) {
        if (c == null) {
            return 0;
        }
        int ret = 0;
        for (int i = 0; i < max && i < 10; i++) {
            if ((c.x + c.y) % 2 == 0) {
                ret++;
            } else {
                ret--;
            }
        }
        return ret;
    }

    public static int noLimitParams(int x, int y, int max) {
        CoordinateStructure c = new CoordinateStructure();
        c.x = x;
        c.y = y;
        int ret = 0;
        for (int i = 0; i < max; i++) {
            if ((c.x + c.y) % 2 == 0) {
                ret++;
            } else {
                ret--;
            }
        }
        return ret;
    }

    public static int noLimit(CoordinateStructure c, int max) {
        if (c == null) {
            return 0;
        }
        int ret = 0;
        for (int i = 0; i < max; i++) {
            if ((c.x + c.y) % 2 == 0) {
                ret++;
            } else {
                ret--;
            }
        }
        return ret;
    }

    public static int arrayOfStructuresParams(int[] xs, int[] ys) {
        if (xs == null || ys == null || xs.length != ys.length) {
            return 0;
        }
        CoordinateStructure[] cs = new CoordinateStructure[xs.length];
        for (int i = 0; i < cs.length; i++) {
            cs[i] = new CoordinateStructure();
            cs[i].x = xs[i];
            cs[i].y = ys[i];
        }
        int ret = 0;
        for (CoordinateStructure c : cs) {
            if ((c.x + c.y) % 2 == 0) {
                ret++;
            } else {
                ret--;
            }
        }
        return ret;
    }

    public static int arrayOfStructures(CoordinateStructure[] cs) {
        if (cs == null) {
            return 0;
        }
        int ret = 0;
        for (CoordinateStructure c : cs) {
            if ((c.x + c.y) % 2 == 0) {
                ret++;
            } else {
                ret--;
            }
        }
        return ret;
    }
}
