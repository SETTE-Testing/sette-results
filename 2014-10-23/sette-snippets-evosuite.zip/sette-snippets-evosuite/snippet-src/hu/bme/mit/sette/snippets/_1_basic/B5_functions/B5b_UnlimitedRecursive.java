package hu.bme.mit.sette.snippets._1_basic.B5_functions;


public final class B5b_UnlimitedRecursive {

    private B5b_UnlimitedRecursive() {
        throw new UnsupportedOperationException("Static class");
    }

    public static int simple(int x) {
        if (x % 100 == 0) {
            return x;
        } else {
            return simple(x - 1);
        }
    }

    public static int fibonacci(int x) {
        if (x <= 0) {
            return 0;
        } else if (x == 1) {
            return 1;
        } else {
            return fibonacci(x - 1) + fibonacci(x - 2);
        }
    }
}
