package hu.bme.mit.sette.snippets._4_generics;


public final class G1_Functions {

    private G1_Functions() {
        throw new UnsupportedOperationException("Static class");
    }

    public static <T> int guessType(T o) {
        if (o == null) {
            return 0;
        } else if (o instanceof Integer) {
            return 1;
        } else if (o instanceof Double) {
            return 2;
        } else if (o instanceof Object) {
            return 3;
        } else {
            throw new RuntimeException();
        }
    }

    public static <T> int guessTypeAndUse(T o) {
        if (o == null) {
            return 0;
        } else if (o instanceof Integer) {
            int i = (Integer) o;
            if (i > 0) {
                return 1;
            } else {
                return -1;
            }
        } else if (o instanceof Double) {
            double d = (Double) o;
            if (d > 0) {
                return 2;
            } else {
                return -2;
            }
        } else if (o instanceof Object) {
            return 3;
        } else {
            throw new RuntimeException();
        }
    }

    public static <T extends Number> int guessTypeWithExtends(T o) {
        if (o == null) {
            return 0;
        } else if (o instanceof Integer) {
            return 1;
        } else if (o instanceof Double) {
            return 2;
        } else if (o instanceof Object) {
            throw new RuntimeException();
        } else {
            throw new RuntimeException();
        }
    }

    public static <T extends Number> int guessTypeWithExtendsAndUse(T o) {
        if (o == null) {
            return 0;
        } else if (o instanceof Integer) {
            int i = (Integer) o;
            if (i > 0) {
                return 1;
            } else {
                return -1;
            }
        } else if (o instanceof Double) {
            double d = (Double) o;
            if (d > 0) {
                return 2;
            } else {
                return -2;
            }
        } else if (o instanceof Object) {
            throw new RuntimeException();
        } else {
            throw new RuntimeException();
        }
    }
}
