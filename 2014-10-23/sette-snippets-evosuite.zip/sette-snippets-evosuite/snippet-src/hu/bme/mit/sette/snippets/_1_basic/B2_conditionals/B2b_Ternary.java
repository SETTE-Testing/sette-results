package hu.bme.mit.sette.snippets._1_basic.B2_conditionals;


public final class B2b_Ternary {

    private B2b_Ternary() {
        throw new UnsupportedOperationException("Static class");
    }

    public static boolean oneParamBoolean(boolean x) {
        return x ? true : false;
    }

    public static boolean twoParamsBoolean(boolean x, boolean y) {
        return x && y ? true : false;
    }

    public static int oneParamInt(int x) {
        return x == 5 ? 1 : 0;
    }

    public static int twoParamsInt(int x, int y) {
        return x == 5 && y == 10 ? 1 : 0;
    }
}
