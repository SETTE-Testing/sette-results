package hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators;


public final class B1c_ArithmeticalOperators {

    private B1c_ArithmeticalOperators() {
        throw new UnsupportedOperationException("Static class");
    }

    public static int add(int x, int y) {
        return x + y;
    }

    public static int addAssignment(int x, int y) {
        x += y;
        return x;
    }

    public static int substract(int x, int y) {
        return x - y;
    }

    public static int substractAssignment(int x, int y) {
        x -= y;
        return x;
    }

    public static int multiply(int x, int y) {
        return x * y;
    }

    public static int multiplyAssignment(int x, int y) {
        x *= y;
        return x;
    }

    public static int divide(int x, int y) {
        return x / y;
    }

    public static int divideAssignment(int x, int y) {
        x /= y;
        return x;
    }

    public static int modulo(int x, int y) {
        return x % y;
    }

    public static int moduloAssignment(int x, int y) {
        x %= y;
        return x;
    }

    public static int unaryPlus(int x) {
        return +x;
    }

    public static int unaryPlusPlus(int x) {
        ++x;
        return x;
    }

    public static int postfixPlusplus(int x) {
        x++;
        return x;
    }

    public static int unaryMinus(int x) {
        return -x;
    }

    public static int unaryMinusMinus(int x) {
        --x;
        return x;
    }

    public static int postfixMinusMinus(int x) {
        x--;
        return x;
    }
}
