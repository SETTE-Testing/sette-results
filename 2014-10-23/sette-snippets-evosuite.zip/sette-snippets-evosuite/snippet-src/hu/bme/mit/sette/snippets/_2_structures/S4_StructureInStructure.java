package hu.bme.mit.sette.snippets._2_structures;

import hu.bme.mit.sette.snippets._2_structures.dependencies.CoordinateStructure;
import hu.bme.mit.sette.snippets._2_structures.dependencies.SegmentStructure;

public final class S4_StructureInStructure {

    private S4_StructureInStructure() {
        throw new UnsupportedOperationException("Static class");
    }

    public static int guessParams(int x1, int y1, int x2, int y2) {
        SegmentStructure s = new SegmentStructure();
        s.p1.x = x1;
        s.p1.y = y1;
        s.p2.x = x2;
        s.p2.y = y2;
        if (s.p1.x == 1 && s.p1.y == 2) {
            if (s.p2.x == 3 && s.p2.y == 4) {
                return 3;
            } else {
                return -1;
            }
        } else {
            if (s.p2.x == 3 && s.p2.y == 4) {
                return 1;
            } else {
                return -3;
            }
        }
    }

    public static int guessCoordinates(CoordinateStructure p1, CoordinateStructure p2) {
        if (p1 == null || p2 == null) {
            return 0;
        }
        SegmentStructure s = new SegmentStructure();
        s.p1 = p1;
        s.p2 = p2;
        if (s.p1.x == 1 && s.p1.y == 2) {
            if (s.p2.x == 3 && s.p2.y == 4) {
                return 3;
            } else {
                return -1;
            }
        } else {
            if (s.p2.x == 3 && s.p2.y == 4) {
                return 1;
            } else {
                return -3;
            }
        }
    }

    public static int guess(SegmentStructure s) {
        if (s == null || s.p1 == null || s.p2 == null) {
            return 0;
        }
        if (s.p1.x == 1 && s.p1.y == 2) {
            if (s.p2.x == 3 && s.p2.y == 4) {
                return 3;
            } else {
                return -1;
            }
        } else {
            if (s.p2.x == 3 && s.p2.y == 4) {
                return 1;
            } else {
                return -3;
            }
        }
    }
}
