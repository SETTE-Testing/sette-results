package hu.bme.mit.sette.snippets._4_generics.dependencies;


/**
 *
 * A generic collection used by the code snippets, whose methods always checks
 * the specified indices. This collection holds exactly 3 elements of the
 * specified type.
 *
 * @param <T>the type of elements in this collection
 */
public class SafeGenericTriplet<T> extends GenericTriplet<T> {

    public SafeGenericTriplet(T item1, T item2, T item3) {
        super(item1, item2, item3);
    }

    @Override
    public T get(int index) {
        if (0 <= index && index < 3) {
            return super.get(index);
        } else {
            return null;
        }
    }

    @Override
    public T set(int index, T newItem) {
        if (0 <= index && index < 3) {
            return super.set(index, newItem);
        } else {
            return null;
        }
    }
}
