package hu.bme.mit.sette.snippets._3_objects;

import hu.bme.mit.sette.snippets._3_objects.dependencies.SimpleObject;

public final class O1_Simple {

    private O1_Simple() {
        throw new UnsupportedOperationException("Static class");
    }

    public static int oneOperationParams(int x) {
        SimpleObject obj = new SimpleObject();
        obj.addAbs(x);
        return obj.getResult();
    }

    public static int oneOperationWithCheck(SimpleObject obj, int x) {
        if (obj == null) {
            return -1;
        }
        obj.addAbs(x);
        return obj.getResult();
    }

    public static int oneOperationNoCheck(SimpleObject obj, int x) {
        obj.addAbs(x);
        return obj.getResult();
    }

    public static int twoOperationsParams(int x1, int x2) {
        SimpleObject obj = new SimpleObject();
        obj.addAbs(x1);
        return obj.chainedAddAbs(x2).getResult();
    }

    public static int twoOperationsWithCheck(SimpleObject obj, int x1, int x2) {
        if (obj == null) {
            return -1;
        }
        obj.addAbs(x1);
        return obj.chainedAddAbs(x2).getResult();
    }

    public static int twoOperationsWithNocheck(SimpleObject obj, int x1, int x2) {
        obj.addAbs(x1);
        return obj.chainedAddAbs(x2).getResult();
    }

    public static int guessResultParams(int x1, int x2, int x3) {
        SimpleObject obj = new SimpleObject();
        obj.addAbs(x1);
        obj.addAbs(x2);
        obj.addAbs(x3);
        if (obj.getResult() == 10) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int guessResult(SimpleObject obj, int x1, int x2, int x3) {
        if (obj == null) {
            return -1;
        }
        obj.addAbs(x1);
        obj.addAbs(x2);
        obj.addAbs(x3);
        if (obj.getResult() == 10) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int guessImpossibleResultParams(int x1, int x2, int x3) {
        SimpleObject obj = new SimpleObject();
        obj.addAbs(x1);
        obj.addAbs(x2);
        obj.addAbs(x3);
        if (obj.getResult() < 0) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int guessImpossibleResult(SimpleObject obj, int x1, int x2, int x3) {
        if (obj == null) {
            return -1;
        }
        obj.addAbs(x1);
        obj.addAbs(x2);
        obj.addAbs(x3);
        if (obj.getResult() < 0) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int guessOperationCountParams(int oc) {
        SimpleObject obj = new SimpleObject();
        for (int i = 0; i < oc; i++) {
            obj.addAbs(1);
        }
        if (obj.getOperationCount() == 5) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int guessOperationCount(SimpleObject obj, int oc) {
        if (obj == null) {
            return -1;
        }
        for (int i = 0; i < oc; i++) {
            obj.addAbs(1);
        }
        if (obj.getOperationCount() == 5) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int guessImpossibleOperationCountParams(int oc) {
        SimpleObject obj = new SimpleObject();
        for (int i = 0; i < oc; i++) {
            obj.addAbs(1);
        }
        if (obj.getOperationCount() < 0) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int guessImpossibleOperationCount(SimpleObject obj, int oc) {
        if (obj == null) {
            return -1;
        }
        for (int i = 0; i < oc; i++) {
            obj.addAbs(1);
        }
        if (obj.getOperationCount() < 0) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int guessResultAndOperationCountParams(int x, int oc) {
        SimpleObject obj = new SimpleObject();
        for (int i = 0; i < oc; i++) {
            obj.addAbs(x);
        }
        if (obj.getResult() == 10 && obj.getOperationCount() == 5) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int guessResultAndOperationCount(SimpleObject obj, int x, int oc) {
        if (obj == null) {
            return -1;
        }
        for (int i = 0; i < oc; i++) {
            obj.addAbs(x);
        }
        if (obj.getResult() == 10 && obj.getOperationCount() == 5) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int guessImpossibleResultAndOperationCountParams(int x, int oc) {
        SimpleObject obj = new SimpleObject();
        for (int i = 0; i < oc; i++) {
            obj.addAbs(x);
        }
        if (obj.getResult() == 10 && obj.getOperationCount() == 4) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int guessImpossibleResultAndOperationCount(SimpleObject obj, int x, int oc) {
        if (obj == null) {
            return -1;
        }
        for (int i = 0; i < oc; i++) {
            obj.addAbs(x);
        }
        if (obj.getResult() == 10 && obj.getOperationCount() == 4) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int guessObject(SimpleObject obj) {
        if (obj == null) {
            return -1;
        }
        if (obj.getOperationCount() == 2 && obj.getResult() == 3) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int guessImpossibleObject(SimpleObject obj) {
        if (obj == null) {
            return -1;
        }
        if (obj.getOperationCount() < 0 || obj.getResult() < 0) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int fullCoverage(SimpleObject obj, int x1, int x2, int oc) {
        if (obj == null) {
            return -1;
        }
        obj.chainedAddAbs(x1).addAbs(x2);
        if (obj.getResult() == 10 && oc == obj.getOperationCount()) {
            return 1;
        } else {
            return 0;
        }
    }
}
