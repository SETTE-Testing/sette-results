package hu.bme.mit.sette.snippets._4_generics;

import hu.bme.mit.sette.snippets._4_generics.dependencies.GenericTriplet;
import hu.bme.mit.sette.snippets._4_generics.dependencies.IntegerTriplet;
import hu.bme.mit.sette.snippets._4_generics.dependencies.SafeGenericTriplet;

public final class G2_Objects {

    private G2_Objects() {
        throw new UnsupportedOperationException("Static class");
    }

    public static boolean guessInteger(GenericTriplet<Integer> obj) {
        if (obj.get(0).equals(new Integer(1))) {
            return true;
        } else {
            return false;
        }
    }

    public static boolean guessIntegerNoHelp(GenericTriplet<?> obj) {
        if (obj.get(0).equals(new Integer(1))) {
            return true;
        } else {
            return false;
        }
    }

    public static boolean guessImpossible(GenericTriplet<Double> obj) {
        if (obj.get(0).equals(new Object())) {
            throw new RuntimeException();
        } else {
            return false;
        }
    }

    public static boolean guessDescendant(IntegerTriplet obj) {
        if (obj.get(0).equals(new Integer(1))) {
            return true;
        } else {
            return false;
        }
    }

    public static boolean guessSafe(SafeGenericTriplet<?> obj) {
        if (obj.get(4) != null) {
            throw new RuntimeException();
        } else {
            return false;
        }
    }

    public static boolean guessSafeNoHelp(GenericTriplet<?> obj) {
        if (obj.get(4) != null) {
            throw new RuntimeException();
        } else {
            return false;
        }
    }
}
