package hu.bme.mit.sette.snippets._2_structures.dependencies;


/**
 * A structure describing a coordinate. Used by the code snippets in S1-S4.
 */
public final class CoordinateStructure {

    public int x = 0;

    public int y = 0;

    public CoordinateStructure() {
    }

    public CoordinateStructure(CoordinateStructure o) {
        if (o == null) {
            return;
        }
        x = o.x;
        y = o.y;
    }
}
