package hu.bme.mit.sette.snippets._6_others;

import hu.bme.mit.sette.snippets._6_others.dependencies.State;

public final class Enum {

    private Enum() {
        throw new UnsupportedOperationException("Static class");
    }

    public static int guessEnum(State s) {
        if (s == null) {
            return -1;
        } else if (s == State.STARTED) {
            return 1;
        } else if (s == State.PAUSED) {
            return 2;
        } else if (s == State.STOPPED) {
            return 3;
        } else if (s == State.IDLE) {
            return 4;
        } else {
            throw new RuntimeException();
        }
    }

    public static int guessEnumString(State s) {
        if (s == null) {
            return -1;
        } else if (s.name().equals("STARTED")) {
            return 1;
        } else if (s.name().equals("PAUSED")) {
            return 2;
        } else if (s.name().equals("STOPPED")) {
            return 3;
        } else if (s.name().equals("IDLE")) {
            return 4;
        } else {
            throw new RuntimeException();
        }
    }

    public static int guessEnumOrdinal(State s) {
        if (s == null) {
            return -1;
        } else if (s.ordinal() == 0) {
            return 1;
        } else if (s.ordinal() == 1) {
            return 2;
        } else if (s.ordinal() == 2) {
            return 3;
        } else if (s.ordinal() == 3) {
            return 4;
        } else {
            throw new RuntimeException();
        }
    }

    public static int switchEnum(State s) {
        if (s == null) {
            return -1;
        }
        switch(s) {
            case STARTED:
                return 1;
            case PAUSED:
                return 2;
            case STOPPED:
                return 3;
            case IDLE:
                return 4;
            default:
                throw new RuntimeException();
        }
    }
}
