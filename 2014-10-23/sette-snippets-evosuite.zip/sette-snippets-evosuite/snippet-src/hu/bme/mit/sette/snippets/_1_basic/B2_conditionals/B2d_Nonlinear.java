package hu.bme.mit.sette.snippets._1_basic.B2_conditionals;


public final class B2d_Nonlinear {

    private B2d_Nonlinear() {
        throw new UnsupportedOperationException("Static class");
    }

    /**
     * Equation: x²+3x-10 = 0<br/>
     * Solution: {x1, x2} = {-5, 2}
     *
     * @param x1
     * @param x2
     * @return
     */
    public static boolean quadraticInt(int x1, int x2) {
        int e1 = x1 * x1 + 3 * x1 - 10;
        int e2 = x2 * x2 + 3 * x2 - 10;
        if (e1 == 0 && e2 == 0 && x1 < x2) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Equation: 2x²+3x-10 = 0<br/>
     * Solution: {x1, x2} = {-3.108495, 1.608495} (not integer)
     *
     * @param x1
     * @param x2
     * @return
     */
    public static boolean quadraticIntNoSolution(int x1, int x2) {
        int e1 = 2 * x1 * x1 + 3 * x1 - 10;
        int e2 = 2 * x2 * x2 + 3 * x2 - 10;
        if (e1 == 0 && e2 == 0 && x1 < x2) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Equation: 2x²+3x-10 = 0 <br/>
     * Solution: {x1, x2} = {-3.108495, 1.608495}<br/>
     * Threshold: 1e-3 (Note: constants and Math.abs() cannot be used because
     * they may not be supported)
     *
     * @param x1
     * @param x2
     * @return
     */
    public static boolean quadraticFloat(float x1, float x2) {
        float e1 = 2 * x1 * x1 + 3 * x1 - 10;
        float e2 = 2 * x2 * x2 + 3 * x2 - 10;
        if (-0.001f < e1 && e1 < 0.001f && -0.001f < e2 && e2 < 0.001f && (x1 + 0.001f) < (x2 - 0.001f)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Equation: 2x²+3x+10 = 0 <br/>
     * Solution: {x1, x2} = {-0.75-2.1065i, -0.75+2.1065i} (not real)<br/>
     * Threshold: 1e-3 (Note: constants and Math.abs() cannot be used because
     * they may not be supported)
     *
     * @param x1
     * @param x2
     * @return
     */
    public static boolean quadraticFloatNoSolution(float x1, float x2) {
        float e1 = 2 * x1 * x1 + 3 * x1 + 10;
        float e2 = 2 * x2 * x2 + 3 * x2 + 10;
        if (-0.001f < e1 && e1 < 0.001f && -0.001f < e2 && e2 < 0.001f && (x1 + 0.001f) < (x2 - 0.001f)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Equation: 2x²+3x-10 = 0 <br/>
     * Solution: {x1, x2} = {-3.108495, 1.608495}<br/>
     * Threshold: 1e-3 (Note: constants and Math.abs() cannot be used because
     * they may not be supported)
     *
     * @param x1
     * @param x2
     * @return
     */
    public static boolean quadraticDouble(double x1, double x2) {
        double e1 = 2 * x1 * x1 + 3 * x1 - 10;
        double e2 = 2 * x2 * x2 + 3 * x2 - 10;
        if (-0.001 < e1 && e1 < 0.001 && -0.001 < e2 && e2 < 0.001 && (x1 + 0.001) < (x2 - 0.001)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Equation: 2x²+3x+10 = 0 <br/>
     * Solution: {x1, x2} = {-0.75-2.1065i, -0.75+2.1065i} (not real)<br/>
     * Threshold: 1e-3 (Note: constants and Math.abs() cannot be used because
     * they may not be supported)
     *
     * @param x1
     * @param x2
     * @return
     */
    public static boolean quadraticDoubleNoSolution(double x1, double x2) {
        double e1 = 2 * x1 * x1 + 3 * x1 + 10;
        double e2 = 2 * x2 * x2 + 3 * x2 + 10;
        if (-0.001 < e1 && e1 < 0.001 && -0.001 < e2 && e2 < 0.001 && (x1 + 0.001) < (x2 - 0.001)) {
            return true;
        } else {
            return false;
        }
    }
}
