package hu.bme.mit.sette.snippets._3_objects.dependencies;


/**
 * An interface for a value setter-getter. Used by the code snippets in O3.
 */
public interface MyInterface {

    int getValue();

    void setValue(int v);

    MyInterface chainedSetValue(int v);
}
