package hu.bme.mit.sette.snippets._6_others.dependencies;


/**
 * Enumeration used by the snippets.
 */
public enum State {

    STARTED, PAUSED, STOPPED, IDLE
}

;
