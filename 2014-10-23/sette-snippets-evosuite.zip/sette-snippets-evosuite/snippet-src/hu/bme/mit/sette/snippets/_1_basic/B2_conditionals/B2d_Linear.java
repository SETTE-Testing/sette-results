package hu.bme.mit.sette.snippets._1_basic.B2_conditionals;


public final class B2d_Linear {

    private B2d_Linear() {
        throw new UnsupportedOperationException("Static class");
    }

    /**
     * Equation: 20x+2 = 42<br/>
     * Solution: x = 2
     *
     * @param x
     * @return
     */
    public static boolean oneParamInt(int x) {
        if (20 * x + 2 == 42) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Equation: 20x+2 = 17<br/>
     * Solution: x = 0.75 (not integer)
     *
     * @param x
     * @return
     */
    public static boolean oneParamIntNoSolution(int x) {
        if (20 * x + 2 == 17) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Equation system:<br/>
     * <br/>
     * x+2y = 3<br/>
     * 3x+4y = 11<br/>
     * <br/>
     * Solution: {x, y} = {5, -1}
     *
     * @param x
     * @param y
     * @return
     */
    public static boolean twoParamsInt(int x, int y) {
        int e1 = x + 2 * y;
        int e2 = 3 * x + 4 * y;
        if (e1 == 3 && e2 == 11) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Equation system:<br/>
     * <br/>
     * x+2y = 3<br/>
     * 3x+4y = 10<br/>
     * <br/>
     * Solution: {x, y} = {4, -0.5} (not integer)
     *
     * @param x
     * @param y
     * @return
     */
    public static boolean twoParamsIntNoSolution(int x, int y) {
        int e1 = x + 2 * y;
        int e2 = 3 * x + 4 * y;
        if (e1 == 3 && e2 == 10) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Equation system:<br/>
     * <br/>
     * x+2y+3z = 9<br/>
     * 3x+y-2z = 10<br/>
     * 5x-y-z = 24<br/>
     * <br/>
     * Solution: {x, y, z} = {5, -1, 2}
     *
     * @param x
     * @param y
     * @param z
     * @return
     */
    public static boolean threeParamsInt(int x, int y, int z) {
        int e1 = x + 2 * y + 3 * z;
        int e2 = 3 * x + y - 2 * z;
        int e3 = 5 * x - y - z;
        if (e1 == 9 && e2 == 10 && e3 == 24) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Equation system:<br/>
     * <br/>
     * x+2y+3z = 9<br/>
     * 3x+y-2z = 10<br/>
     * 5x-y-z = 23<br/>
     * <br/>
     * Solution: {x, y, z} = {198/41, -30/41, 77/41}<br/>
     * Solution with overflow (32bit integer): {x, y, z} = {-1257063594,
     * 1361818898, 942797701}
     *
     * @param x
     * @param y
     * @param z
     * @return
     */
    public static boolean threeParamsIntNoSolution(int x, int y, int z) {
        int e1 = x + 2 * y + 3 * z;
        int e2 = 3 * x + y - 2 * z;
        int e3 = 5 * x - y - z;
        if (e1 == 9 && e2 == 10 && e3 == 23) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Equation: 20x+2 = 17<br/>
     * Solution: x = 0.75
     * 
     * (0.75 = 3/4 can be precisely represented, see IEEE 754)
     *
     * @param x
     * @return
     */
    public static boolean oneParamFloat(float x) {
        if (20 * x + 2 == 17) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Equation system:<br/>
     * <br/>
     * x+2y = 3<br/>
     * 3x+4y = 10<br/>
     * <br/>
     * Solution: {x, y} = {4, -0.5}
     * 
     * (-0.5 = -1/2 can be precisely represented, see IEEE 754)
     *
     * @param x
     * @param y
     * @return
     */
    public static boolean twoParamsFloat(float x, float y) {
        float e1 = x + 2 * y;
        float e2 = 3 * x + 4 * y;
        if (e1 == 3 && e2 == 10) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Equation system:<br/>
     * <br/>
     * x+2y+3z = 9<br/>
     * 3x+y-2z = 10<br/>
     * 5x-y-z = 23<br/>
     * <br/>
     * Solution: {x, y, z} = {198/41, -30/41, 77/41}<br/>
     * Threshold: 1e-3 (Note: constants and Math.abs() cannot be used because
     * they may not be supported)
     *
     * @param x
     * @param y
     * @param z
     * @return
     */
    public static boolean threeParamsFloat(float x, float y, float z) {
        float e1 = x + 2 * y + 3 * z;
        float e2 = 3 * x + y - 2 * z;
        float e3 = 5 * x - y - z;
        if (8.999f < e1 && e1 < 9.001f && 9.999f < e2 && e2 < 10.001f && 22.999f < e3 && e3 < 23.001f) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Equation: 20x+2 = 17<br/>
     * Solution: x = 0.75
     * 
     * (0.75 = 3/4 can be precisely represented, see IEEE 754)
     * 
     * @param x
     * @return
     */
    public static boolean oneParamDouble(double x) {
        if (20 * x + 2 == 17) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Equation system:<br/>
     * <br/>
     * x+2y = 3<br/>
     * 3x+4y = 10<br/>
     * <br/>
     * Solution: {x, y} = {4, -0.5}
     * 
     * (-0.5 = -1/2 can be precisely represented, see IEEE 754)
     *
     * @param x
     * @param y
     * @return
     */
    public static boolean twoParamsDouble(double x, double y) {
        double e1 = x + 2 * y;
        double e2 = 3 * x + 4 * y;
        if (e1 == 3 && e2 == 10) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Equation system:<br/>
     * <br/>
     * x+2y+3z = 9<br/>
     * 3x+y-2z = 10<br/>
     * 5x-y-z = 23<br/>
     * <br/>
     * Solution: {x, y, z} = {198/41, -30/41, 77/41} <br/>
     * Threshold: 1e-3 (Note: constants and Math.abs() cannot be used because
     * they may not be supported)
     *
     * @param x
     * @param y
     * @param z
     * @return
     */
    public static boolean threeParamsDouble(double x, double y, double z) {
        double e1 = x + 2 * y + 3 * z;
        double e2 = 3 * x + y - 2 * z;
        double e3 = 5 * x - y - z;
        if (8.999 < e1 && e1 < 9.001 && 9.999 < e2 && e2 < 10.001 && 22.999 < e3 && e3 < 23.001) {
            return true;
        } else {
            return false;
        }
    }
}
