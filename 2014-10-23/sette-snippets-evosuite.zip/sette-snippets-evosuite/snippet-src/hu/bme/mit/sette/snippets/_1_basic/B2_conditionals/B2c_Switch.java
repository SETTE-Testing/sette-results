package hu.bme.mit.sette.snippets._1_basic.B2_conditionals;


public final class B2c_Switch {

    private B2c_Switch() {
        throw new UnsupportedOperationException("Static class");
    }

    public static int simple(int x) {
        int ret;
        switch(x) {
            case 0:
                ret = 0;
                break;
            case 1:
                ret = 1;
                break;
            case 2:
                ret = 4;
                break;
            default:
                ret = -1;
                break;
        }
        return ret;
    }

    public static int missingBreaks(int x) {
        int ret;
        switch(x) {
            case 0:
                ret = 0;
            case 1:
                ret = 1;
                break;
            case 2:
                ret = 4;
            default:
                ret = -1;
                break;
        }
        return ret;
    }

    public static int withReturn(int x) {
        int ret;
        switch(x) {
            case 0:
                return 0;
            case 1:
                return 1;
            case 2:
                ret = 4;
                break;
            default:
                ret = -1;
                break;
        }
        return ret;
    }
}
