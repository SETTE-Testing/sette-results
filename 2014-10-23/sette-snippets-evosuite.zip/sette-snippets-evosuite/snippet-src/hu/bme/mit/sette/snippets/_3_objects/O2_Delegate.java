package hu.bme.mit.sette.snippets._3_objects;

import hu.bme.mit.sette.snippets._3_objects.dependencies.SimpleObject;
import hu.bme.mit.sette.snippets._3_objects.dependencies.SimpleObjectDelegate;

public final class O2_Delegate {

    private O2_Delegate() {
        throw new UnsupportedOperationException("Static class");
    }

    public static int guessResultParams(int x1, int x2, int x3) {
        SimpleObjectDelegate obj = new SimpleObjectDelegate(new SimpleObject());
        obj.addAbs(x1);
        obj.addAbs(x2);
        obj.addAbs(x3);
        if (obj.getResult() == 10) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int guessResult(SimpleObjectDelegate obj, int x1, int x2, int x3) {
        if (obj == null) {
            return -1;
        }
        obj.addAbs(x1);
        obj.addAbs(x2);
        obj.addAbs(x3);
        if (obj.getResult() == 10) {
            return 1;
        } else {
            return 0;
        }
    }
}
