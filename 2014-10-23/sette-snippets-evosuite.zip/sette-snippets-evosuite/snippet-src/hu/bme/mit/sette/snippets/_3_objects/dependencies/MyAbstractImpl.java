package hu.bme.mit.sette.snippets._3_objects.dependencies;


/**
 * Implementation of the value setter-getter interface. Used by the code
 * snippets in O3.
 */
public class MyAbstractImpl extends MyAbstract {

    private int value;

    @Override
    public int getValue() {
        return value;
    }

    @Override
    public void setValue(int v) {
        value = v;
    }
}
