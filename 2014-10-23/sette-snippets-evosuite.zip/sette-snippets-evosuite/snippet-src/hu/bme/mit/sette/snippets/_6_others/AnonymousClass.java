package hu.bme.mit.sette.snippets._6_others;

import hu.bme.mit.sette.snippets._6_others.dependencies.AnonymousClassInterface;

public final class AnonymousClass {

    private AnonymousClass() {
        throw new UnsupportedOperationException("Static class");
    }

    public static int test(int x) {
        AnonymousClassInterface a = new AnonymousClassInterface() {

            @Override
            public int method(int x) {
                if (x < 0) {
                    return -x;
                } else {
                    return x;
                }
            }
        };
        return a.method(x);
    }
}
