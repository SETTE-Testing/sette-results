package hu.bme.mit.sette.snippets._3_objects.dependencies;


/**
 * The object type used by the code snippets O1-O4.
 */
public class SimpleObject {

    protected int result = 0;

    protected int operationCount = 0;

    public void addAbs(int x) {
        if (x > 0) {
            result += x;
        } else {
            result -= x;
        }
        operationCount++;
    }

    public SimpleObject chainedAddAbs(int x) {
        addAbs(x);
        return this;
    }

    public int getResult() {
        return result;
    }

    public int getOperationCount() {
        return operationCount;
    }
}
