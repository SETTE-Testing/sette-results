package hu.bme.mit.sette.snippets._2_structures.dependencies;


/**
 * A structure describing a segment. Used by the code snippets in S4.
 */
public final class SegmentStructure {

    public CoordinateStructure p1 = new CoordinateStructure();

    public CoordinateStructure p2 = new CoordinateStructure();

    public SegmentStructure() {
    }

    public SegmentStructure(SegmentStructure o) {
        if (o == null) {
            return;
        }
        p1 = new CoordinateStructure(o.p1);
        p2 = new CoordinateStructure(o.p2);
    }
}
