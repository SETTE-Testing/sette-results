package hu.bme.mit.sette.snippets._3_objects;

import hu.bme.mit.sette.snippets._3_objects.dependencies.MyInterface;

public final class O3b_Interface {

    private O3b_Interface() {
        throw new UnsupportedOperationException("Static class");
    }

    public static int guess(MyInterface obj, int v) {
        if (obj == null) {
            return -1;
        }
        obj.setValue(v);
        if (obj.getValue() == 10) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int validate(MyInterface obj, int v) {
        if (obj == null) {
            return -1;
        }
        obj.setValue(v);
        if (obj.getValue() == v) {
            return 1;
        } else {
            throw new RuntimeException();
        }
    }

    public static int guessImpossible(MyInterface obj, int v) {
        if (obj == null) {
            return -1;
        }
        obj.setValue(v);
        if (obj.getValue() == v + 1) {
            throw new RuntimeException();
        } else {
            return 1;
        }
    }
}
