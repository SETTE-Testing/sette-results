package hu.bme.mit.sette.snippets._3_objects.dependencies;


/**
 * The extended object type used by the code snippets O3.
 */
public class SimpleExtendedObject extends SimpleObject {

    public void subtractAbs(int x) {
        if (x < 0) {
            result += x;
        } else {
            result -= x;
        }
        operationCount++;
    }
}
