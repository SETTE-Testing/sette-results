package hu.bme.mit.sette.snippets._2_structures;

import hu.bme.mit.sette.snippets._2_structures.dependencies.CoordinateStructure;

public final class S1_BasicUsage {

    private S1_BasicUsage() {
        throw new UnsupportedOperationException("Static class");
    }

    public static int useStructureParams(int x, int y) {
        CoordinateStructure c = new CoordinateStructure();
        c.x = x;
        c.y = y;
        return c.x + c.y;
    }

    public static int useStructure(CoordinateStructure c) {
        if (c == null) {
            return 0;
        }
        return c.x + c.y;
    }

    public static CoordinateStructure returnStructureParams(int x, int y) {
        CoordinateStructure c = new CoordinateStructure();
        c.x = x;
        c.y = y;
        c.x = -c.x;
        c.y = -c.y;
        return c;
    }

    public static CoordinateStructure returnStructure(CoordinateStructure c) {
        if (c == null) {
            return null;
        }
        c.x = -c.x;
        c.y = -c.y;
        return c;
    }
}
