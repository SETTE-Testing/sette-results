package hu.bme.mit.sette.snippets._3_objects.dependencies;


/**
 * The object type with method override used by the code snippets O4.
 */
public class SimpleObjectOverride extends SimpleObject {

    @Override
    public void addAbs(int x) {
        if (0 < x) {
            x = 0;
        }
        super.addAbs(x);
    }
}
