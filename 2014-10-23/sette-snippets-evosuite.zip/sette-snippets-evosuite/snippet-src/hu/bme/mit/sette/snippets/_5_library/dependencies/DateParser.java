package hu.bme.mit.sette.snippets._5_library.dependencies;

import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Class realising a date parser based on regular expressions.
 */
public final class DateParser {

    private static final Pattern pattern = Pattern.compile("(\\d{4})-(\\d{2})-(\\d{2})");

    public DateParser() {
    }

    public Date parse(String s) {
        if (s == null) {
            throw new IllegalArgumentException();
        }
        Matcher m = DateParser.pattern.matcher(s);
        if (m.matches()) {
            Calendar cal = Calendar.getInstance();
            cal.setTimeZone(TimeZone.getTimeZone("GMT"));
            cal.set(Integer.parseInt(m.group(1)), Integer.parseInt(m.group(2)) - 1, Integer.parseInt(m.group(3)));
            return cal.getTime();
        } else {
            return null;
        }
    }
}
