package hu.bme.mit.sette.snippets._1_basic.B2_conditionals;


public final class B2a_IfElse {

    private B2a_IfElse() {
        throw new UnsupportedOperationException("Static class");
    }

    public static int oneParamBoolean(boolean x) {
        if (x) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int twoParamsBoolean(boolean x, boolean y) {
        if (x && y) {
            return 1;
        } else if (!x && y) {
            return 2;
        } else if (!x && !y) {
            return 3;
        } else if (x && !y) {
            return 4;
        } else if (x && !y) {
            return -1;
        } else {
            return -2;
        }
    }

    public static int oneParamInt(int x) {
        if (x == 12345) {
            return 2;
        }
        if (x > 0) {
            return 1;
        } else if (x < 0) {
            return -1;
        } else {
            return 0;
        }
    }

    public static int twoParamsInt(int x, int y) {
        if (x > 0 && y > 0) {
            return 1;
        } else if (x < 0 && y > 0) {
            return 2;
        } else if (x < 0 && y < 0) {
            return 3;
        } else if (x > 0 && y < 0) {
            return 4;
        } else if (x > 0 && y < 0) {
            return -1;
        } else if (x == 0 || y == 0) {
            return 0;
        } else {
            return -2;
        }
    }

    public static int oneParamDouble(double x) {
        if (x == 12345.0) {
            return 2;
        } else if (x > 0) {
            return 1;
        } else if (x < 0) {
            return -1;
        } else {
            return 0;
        }
    }

    public static int twoParamsDouble(double x, double y) {
        if (x > 0 && y > 0) {
            return 1;
        } else if (x < 0 && y > 0) {
            return 2;
        } else if (x < 0 && y < 0) {
            return 3;
        } else if (x > 0 && y < 0) {
            return 4;
        } else if (x > 0 && y < 0) {
            return -1;
        } else if (x == 0 || y == 0) {
            return 0;
        } else {
            return -2;
        }
    }
}
