package hu.bme.mit.sette.snippets._3_objects;

import hu.bme.mit.sette.snippets._3_objects.dependencies.SimpleExtendedObject;
import hu.bme.mit.sette.snippets._3_objects.dependencies.SimpleObject;

public final class O3a_Inheritance {

    private O3a_Inheritance() {
        throw new UnsupportedOperationException("Static class");
    }

    public static int guessResultParams(int x1, int x2, int x3) {
        SimpleExtendedObject obj = new SimpleExtendedObject();
        obj.addAbs(x1);
        obj.addAbs(x2);
        obj.subtractAbs(x3);
        if (obj.getResult() == 10) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int guessResult(SimpleExtendedObject obj, int x1, int x2, int x3) {
        if (obj == null) {
            return -1;
        }
        obj.addAbs(x1);
        obj.addAbs(x2);
        obj.subtractAbs(x3);
        if (obj.getResult() == 10) {
            return 1;
        } else {
            return 0;
        }
    }
}
