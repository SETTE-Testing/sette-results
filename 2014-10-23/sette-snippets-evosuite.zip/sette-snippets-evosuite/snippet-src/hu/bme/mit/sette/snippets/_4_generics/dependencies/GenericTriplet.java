package hu.bme.mit.sette.snippets._4_generics.dependencies;


/**
 * A generic collection used by the code snippets. This collection holds exactly
 * 3 elements of the specified type.
 *
 * @param <T>the type of elements in this collection
 */
public class GenericTriplet<T> {

    private final Object[] array = new Object[3];

    public GenericTriplet(T item1, T item2, T item3) {
        this.array[0] = item1;
        this.array[1] = item2;
        this.array[2] = item3;
    }

    @SuppressWarnings("unchecked")
    public T get(int index) {
        return (T) this.array[index];
    }

    public T set(int index, T newItem) {
        T old = this.get(index);
        this.array[index] = newItem;
        return old;
    }

    public int size() {
        return this.array.length;
    }
}
