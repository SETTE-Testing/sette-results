package hu.bme.mit.sette.snippets._5_library;


public final class L3_Wrappers {

    private L3_Wrappers() {
        throw new UnsupportedOperationException("Static class");
    }

    public static Integer guessInteger(Integer a) {
        if (a == 1) {
            return 1;
        } else if (a.equals(new Integer(2))) {
            return 2;
        } else {
            return -1;
        }
    }

    public static Integer integerOverflow(Integer a, Integer b) {
        Integer sum = a + b;
        if (sum < a || sum < b) {
            return Integer.MAX_VALUE;
        } else {
            return sum;
        }
    }

    public static Double guessDouble(Double a) {
        if (a == 1) {
            return 1.0;
        } else if (a.equals(new Double(2))) {
            return 2.0;
        } else {
            return -1.0;
        }
    }
}
