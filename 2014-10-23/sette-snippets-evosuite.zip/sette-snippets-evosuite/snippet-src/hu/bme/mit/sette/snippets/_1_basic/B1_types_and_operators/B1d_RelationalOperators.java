package hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators;


public final class B1d_RelationalOperators {

    private B1d_RelationalOperators() {
        throw new UnsupportedOperationException("Static class");
    }

    public static boolean equal(int x, int y) {
        return x == y;
    }

    public static boolean notEqual(int x, int y) {
        return x != y;
    }

    public static boolean smaller(int x, int y) {
        return x < y;
    }

    public static boolean smallerOrEqual(int x, int y) {
        return x <= y;
    }

    public static boolean greater(int x, int y) {
        return x > y;
    }

    public static boolean greaterOrEqual(int x, int y) {
        return x >= y;
    }

    public static boolean and(boolean x, boolean y) {
        return x && y;
    }

    public static boolean or(boolean x, boolean y) {
        return x || y;
    }

    public static boolean negate(boolean x) {
        return !x;
    }
}
