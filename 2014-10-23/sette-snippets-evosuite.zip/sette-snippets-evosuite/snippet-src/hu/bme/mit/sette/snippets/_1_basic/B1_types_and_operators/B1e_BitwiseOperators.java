package hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators;


public final class B1e_BitwiseOperators {

    private B1e_BitwiseOperators() {
        throw new UnsupportedOperationException("Static class");
    }

    public static int shiftLeft(int x, int y) {
        return x << y;
    }

    public static int shiftLeftAssignment(int x, int y) {
        x <<= y;
        return x;
    }

    public static int shiftRight(int x, int y) {
        return x >> y;
    }

    public static int shiftRightAssignment(int x, int y) {
        x >>= y;
        return x;
    }

    public static int shiftRightUnsigned(int x, int y) {
        return x >>> y;
    }

    public static int shiftRightUnsignedAssignment(int x, int y) {
        x >>>= y;
        return x;
    }

    public static int and(int x, int y) {
        return x & y;
    }

    public static int andAssignment(int x, int y) {
        x &= y;
        return x;
    }

    public static int or(int x, int y) {
        return x | y;
    }

    public static int orAssignment(int x, int y) {
        x |= y;
        return x;
    }

    public static int xor(int x, int y) {
        return x ^ y;
    }

    public static int xorAssignment(int x, int y) {
        x ^= y;
        return x;
    }

    public static int negate(int x) {
        return ~x;
    }
}
