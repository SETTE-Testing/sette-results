package hu.bme.mit.sette.snippets._3_objects.dependencies;


/**
 * Implementation for the value setter-getter interface. Used by the code
 * snippets in O3.
 */
public class MyInterfaceImpl implements MyInterface {

    private int value;

    @Override
    public int getValue() {
        return value;
    }

    @Override
    public void setValue(int v) {
        value = v;
    }

    @Override
    public MyInterfaceImpl chainedSetValue(int v) {
        setValue(v);
        return this;
    }
}
