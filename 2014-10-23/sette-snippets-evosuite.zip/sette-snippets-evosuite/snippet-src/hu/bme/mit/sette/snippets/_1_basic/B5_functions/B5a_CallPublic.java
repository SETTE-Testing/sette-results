package hu.bme.mit.sette.snippets._1_basic.B5_functions;


public final class B5a_CallPublic {

    private B5a_CallPublic() {
        throw new UnsupportedOperationException("Static class");
    }

    public static int calledFunction(int x, int y) {
        if (x > 0 && y > 0) {
            return 1;
        } else if (x < 0 && y > 0) {
            return 2;
        } else if (x < 0 && y < 0) {
            return 3;
        } else if (x > 0 && y < 0) {
            return 4;
        } else {
            return -1;
        }
    }

    public static int simple(int x, int y) {
        return calledFunction(x, y);
    }

    public static int useReturnValue(int x, int y) {
        if (calledFunction(x, y) >= 0) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int conditionalCall(int x, int y, boolean z) {
        if (z) {
            return calledFunction(x, y);
        } else {
            return -2;
        }
    }
}
