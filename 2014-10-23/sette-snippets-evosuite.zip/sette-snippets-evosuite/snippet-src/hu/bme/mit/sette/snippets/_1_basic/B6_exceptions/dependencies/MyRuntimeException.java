package hu.bme.mit.sette.snippets._1_basic.B6_exceptions.dependencies;


/**
 * Own runtime exception class.
 */
public final class MyRuntimeException extends RuntimeException {

    private static final long serialVersionUID = -8827472018871339228L;

    public MyRuntimeException() {
        super();
    }
}
