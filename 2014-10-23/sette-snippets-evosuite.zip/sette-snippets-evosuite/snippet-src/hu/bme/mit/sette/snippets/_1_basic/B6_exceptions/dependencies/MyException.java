package hu.bme.mit.sette.snippets._1_basic.B6_exceptions.dependencies;


/**
 * Own exception class.
 */
public final class MyException extends Exception {

    private static final long serialVersionUID = -3158036931121505753L;

    public MyException() {
        super();
    }
}
