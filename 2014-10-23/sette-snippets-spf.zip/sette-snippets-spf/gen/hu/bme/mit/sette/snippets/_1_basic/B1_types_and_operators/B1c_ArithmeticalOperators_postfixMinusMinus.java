package hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators;

import hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators.B1c_ArithmeticalOperators;

public final class B1c_ArithmeticalOperators_postfixMinusMinus {
    public static void main(String[] args) throws Exception {
        B1c_ArithmeticalOperators.postfixMinusMinus(1);
    }
}
