package hu.bme.mit.sette.snippets._6_others;

import hu.bme.mit.sette.snippets._6_others.ThirdParty;

public final class ThirdParty_minMaxWithOrder {
    public static void main(String[] args) throws Exception {
        ThirdParty.minMaxWithOrder(1, 1);
    }
}
