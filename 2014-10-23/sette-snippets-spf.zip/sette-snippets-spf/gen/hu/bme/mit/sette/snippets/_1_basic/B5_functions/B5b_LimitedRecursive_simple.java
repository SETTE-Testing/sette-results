package hu.bme.mit.sette.snippets._1_basic.B5_functions;

import hu.bme.mit.sette.snippets._1_basic.B5_functions.B5b_LimitedRecursive;

public final class B5b_LimitedRecursive_simple {
    public static void main(String[] args) throws Exception {
        B5b_LimitedRecursive.simple(1);
    }
}
