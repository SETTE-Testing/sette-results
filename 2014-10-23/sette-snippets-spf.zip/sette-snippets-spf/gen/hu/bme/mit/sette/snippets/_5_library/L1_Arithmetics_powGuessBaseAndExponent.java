package hu.bme.mit.sette.snippets._5_library;

import hu.bme.mit.sette.snippets._5_library.L1_Arithmetics;

public final class L1_Arithmetics_powGuessBaseAndExponent {
    public static void main(String[] args) throws Exception {
        L1_Arithmetics.powGuessBaseAndExponent(1.0, 1.0);
    }
}
