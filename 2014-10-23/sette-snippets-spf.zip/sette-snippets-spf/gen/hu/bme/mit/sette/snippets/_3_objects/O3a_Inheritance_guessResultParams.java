package hu.bme.mit.sette.snippets._3_objects;

import hu.bme.mit.sette.snippets._3_objects.O3a_Inheritance;

public final class O3a_Inheritance_guessResultParams {
    public static void main(String[] args) throws Exception {
        O3a_Inheritance.guessResultParams(1, 1, 1);
    }
}
