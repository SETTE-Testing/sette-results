package hu.bme.mit.sette.snippets._2_structures;

import hu.bme.mit.sette.snippets._2_structures.S1_BasicUsage;

public final class S1_BasicUsage_useStructureParams {
    public static void main(String[] args) throws Exception {
        S1_BasicUsage.useStructureParams(1, 1);
    }
}
