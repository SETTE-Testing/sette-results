package hu.bme.mit.sette.snippets._6_others;

import hu.bme.mit.sette.snippets._6_others.Varargs;

public final class Varargs_iterateWithFor {
    public static void main(String[] args) throws Exception {
        Varargs.iterateWithFor(null);
    }
}
