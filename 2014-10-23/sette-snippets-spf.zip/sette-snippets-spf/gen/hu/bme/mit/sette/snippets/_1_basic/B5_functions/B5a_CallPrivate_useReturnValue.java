package hu.bme.mit.sette.snippets._1_basic.B5_functions;

import hu.bme.mit.sette.snippets._1_basic.B5_functions.B5a_CallPrivate;

public final class B5a_CallPrivate_useReturnValue {
    public static void main(String[] args) throws Exception {
        B5a_CallPrivate.useReturnValue(1, 1);
    }
}
