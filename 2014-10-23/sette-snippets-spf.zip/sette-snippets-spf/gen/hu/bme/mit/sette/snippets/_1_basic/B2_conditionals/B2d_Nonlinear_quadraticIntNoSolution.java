package hu.bme.mit.sette.snippets._1_basic.B2_conditionals;

import hu.bme.mit.sette.snippets._1_basic.B2_conditionals.B2d_Nonlinear;

public final class B2d_Nonlinear_quadraticIntNoSolution {
    public static void main(String[] args) throws Exception {
        B2d_Nonlinear.quadraticIntNoSolution(1, 1);
    }
}
