package hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators;

import hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators.B1b_Constants;

public final class B1b_Constants_constLong {
    public static void main(String[] args) throws Exception {
        B1b_Constants.constLong();
    }
}
