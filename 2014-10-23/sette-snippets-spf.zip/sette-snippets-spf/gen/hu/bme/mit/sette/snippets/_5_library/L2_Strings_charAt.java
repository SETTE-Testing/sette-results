package hu.bme.mit.sette.snippets._5_library;

import hu.bme.mit.sette.snippets._5_library.L2_Strings;

public final class L2_Strings_charAt {
    public static void main(String[] args) throws Exception {
        L2_Strings.charAt(null);
    }
}
