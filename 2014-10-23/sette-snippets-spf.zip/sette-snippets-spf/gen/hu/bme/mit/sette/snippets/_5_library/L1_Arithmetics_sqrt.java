package hu.bme.mit.sette.snippets._5_library;

import hu.bme.mit.sette.snippets._5_library.L1_Arithmetics;

public final class L1_Arithmetics_sqrt {
    public static void main(String[] args) throws Exception {
        L1_Arithmetics.sqrt(1.0);
    }
}
