package hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators;

import hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators.B1d_RelationalOperators;

public final class B1d_RelationalOperators_smaller {
    public static void main(String[] args) throws Exception {
        B1d_RelationalOperators.smaller(1, 1);
    }
}
