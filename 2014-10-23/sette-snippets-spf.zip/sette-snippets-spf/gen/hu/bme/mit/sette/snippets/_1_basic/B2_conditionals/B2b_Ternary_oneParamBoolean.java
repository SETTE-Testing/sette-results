package hu.bme.mit.sette.snippets._1_basic.B2_conditionals;

import hu.bme.mit.sette.snippets._1_basic.B2_conditionals.B2b_Ternary;

public final class B2b_Ternary_oneParamBoolean {
    public static void main(String[] args) throws Exception {
        B2b_Ternary.oneParamBoolean(false);
    }
}
