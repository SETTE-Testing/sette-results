package hu.bme.mit.sette.snippets._1_basic.B6_exceptions;

import hu.bme.mit.sette.snippets._1_basic.B6_exceptions.B6b_UncheckedExceptions;

public final class B6b_UncheckedExceptions_call {
    public static void main(String[] args) throws Exception {
        B6b_UncheckedExceptions.call(1, 1);
    }
}
