package hu.bme.mit.sette.snippets._4_generics;

import hu.bme.mit.sette.snippets._4_generics.G2_Objects;

public final class G2_Objects_guessImpossible {
    public static void main(String[] args) throws Exception {
        G2_Objects.guessImpossible(null);
    }
}
