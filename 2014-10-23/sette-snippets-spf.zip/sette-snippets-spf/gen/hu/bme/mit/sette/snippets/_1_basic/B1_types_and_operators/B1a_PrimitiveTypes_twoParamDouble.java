package hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators;

import hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators.B1a_PrimitiveTypes;

public final class B1a_PrimitiveTypes_twoParamDouble {
    public static void main(String[] args) throws Exception {
        B1a_PrimitiveTypes.twoParamDouble(1.0, 1.0);
    }
}
