package hu.bme.mit.sette.snippets._3_objects;

import hu.bme.mit.sette.snippets._3_objects.O3b_Interface;

public final class O3b_Interface_validate {
    public static void main(String[] args) throws Exception {
        O3b_Interface.validate(null, 1);
    }
}
