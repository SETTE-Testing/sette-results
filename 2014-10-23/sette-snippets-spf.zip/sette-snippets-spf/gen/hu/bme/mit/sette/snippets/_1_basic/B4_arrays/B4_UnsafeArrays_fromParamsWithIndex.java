package hu.bme.mit.sette.snippets._1_basic.B4_arrays;

import hu.bme.mit.sette.snippets._1_basic.B4_arrays.B4_UnsafeArrays;

public final class B4_UnsafeArrays_fromParamsWithIndex {
    public static void main(String[] args) throws Exception {
        B4_UnsafeArrays.fromParamsWithIndex(1, 1, 1, 1);
    }
}
