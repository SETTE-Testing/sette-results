package hu.bme.mit.sette.snippets._5_library;

import hu.bme.mit.sette.snippets._5_library.L4_Collections;

public final class L4_Collections_guessGenericListWithElement {
    public static void main(String[] args) throws Exception {
        L4_Collections.guessGenericListWithElement(null);
    }
}
