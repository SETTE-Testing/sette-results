package hu.bme.mit.sette.snippets._6_others;

import hu.bme.mit.sette.snippets._6_others.ThirdParty;

public final class ThirdParty_minMax {
    public static void main(String[] args) throws Exception {
        ThirdParty.minMax(1, 1);
    }
}
