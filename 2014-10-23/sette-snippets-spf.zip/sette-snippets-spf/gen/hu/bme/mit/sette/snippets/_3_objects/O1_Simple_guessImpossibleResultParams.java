package hu.bme.mit.sette.snippets._3_objects;

import hu.bme.mit.sette.snippets._3_objects.O1_Simple;

public final class O1_Simple_guessImpossibleResultParams {
    public static void main(String[] args) throws Exception {
        O1_Simple.guessImpossibleResultParams(1, 1, 1);
    }
}
