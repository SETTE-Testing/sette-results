package hu.bme.mit.sette.snippets._3_objects;

import hu.bme.mit.sette.snippets._3_objects.O4_Override;

public final class O4_Override_guessImpossible {
    public static void main(String[] args) throws Exception {
        O4_Override.guessImpossible(null, 1, 1, 1);
    }
}
