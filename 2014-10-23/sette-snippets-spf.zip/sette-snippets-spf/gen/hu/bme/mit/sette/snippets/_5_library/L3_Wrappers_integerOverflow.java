package hu.bme.mit.sette.snippets._5_library;

import hu.bme.mit.sette.snippets._5_library.L3_Wrappers;

public final class L3_Wrappers_integerOverflow {
    public static void main(String[] args) throws Exception {
        L3_Wrappers.integerOverflow(1, 1);
    }
}
