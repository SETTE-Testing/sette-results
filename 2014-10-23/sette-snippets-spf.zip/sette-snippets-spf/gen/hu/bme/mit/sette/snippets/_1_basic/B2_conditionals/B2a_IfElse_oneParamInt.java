package hu.bme.mit.sette.snippets._1_basic.B2_conditionals;

import hu.bme.mit.sette.snippets._1_basic.B2_conditionals.B2a_IfElse;

public final class B2a_IfElse_oneParamInt {
    public static void main(String[] args) throws Exception {
        B2a_IfElse.oneParamInt(1);
    }
}
