package hu.bme.mit.sette.snippets._4_generics;

import hu.bme.mit.sette.snippets._4_generics.G1_Functions;

public final class G1_Functions_guessTypeAndUse {
    public static void main(String[] args) throws Exception {
        G1_Functions.guessTypeAndUse(null);
    }
}
