package hu.bme.mit.sette.snippets._1_basic.B6_exceptions;

import hu.bme.mit.sette.snippets._1_basic.B6_exceptions.B6c_CommonRuntimeExceptions;

public final class B6c_CommonRuntimeExceptions_arrayIndexOutOfBoundsException {
    public static void main(String[] args) throws Exception {
        B6c_CommonRuntimeExceptions.arrayIndexOutOfBoundsException(false);
    }
}
