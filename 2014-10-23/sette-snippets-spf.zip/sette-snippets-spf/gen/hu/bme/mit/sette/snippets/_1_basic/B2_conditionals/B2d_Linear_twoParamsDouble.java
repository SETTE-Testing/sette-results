package hu.bme.mit.sette.snippets._1_basic.B2_conditionals;

import hu.bme.mit.sette.snippets._1_basic.B2_conditionals.B2d_Linear;

public final class B2d_Linear_twoParamsDouble {
    public static void main(String[] args) throws Exception {
        B2d_Linear.twoParamsDouble(1.0, 1.0);
    }
}
