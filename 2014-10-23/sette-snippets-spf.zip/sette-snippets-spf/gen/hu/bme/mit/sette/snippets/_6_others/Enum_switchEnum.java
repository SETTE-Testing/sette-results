package hu.bme.mit.sette.snippets._6_others;

import hu.bme.mit.sette.snippets._6_others.Enum;

public final class Enum_switchEnum {
    public static void main(String[] args) throws Exception {
        Enum.switchEnum(null);
    }
}
