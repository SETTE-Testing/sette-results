package hu.bme.mit.sette.snippets._2_structures;

import hu.bme.mit.sette.snippets._2_structures.S2_WithConditionals;

public final class S2_WithConditionals_twoStructures {
    public static void main(String[] args) throws Exception {
        S2_WithConditionals.twoStructures(null, null);
    }
}
