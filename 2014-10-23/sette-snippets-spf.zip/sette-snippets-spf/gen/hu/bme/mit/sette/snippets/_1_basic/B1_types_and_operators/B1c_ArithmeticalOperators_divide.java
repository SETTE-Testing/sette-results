package hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators;

import hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators.B1c_ArithmeticalOperators;

public final class B1c_ArithmeticalOperators_divide {
    public static void main(String[] args) throws Exception {
        B1c_ArithmeticalOperators.divide(1, 1);
    }
}
