package hu.bme.mit.sette.snippets._2_structures;

import hu.bme.mit.sette.snippets._2_structures.S2_WithConditionals;

public final class S2_WithConditionals_twoStructuresParams {
    public static void main(String[] args) throws Exception {
        S2_WithConditionals.twoStructuresParams(1, 1, 1, 1);
    }
}
