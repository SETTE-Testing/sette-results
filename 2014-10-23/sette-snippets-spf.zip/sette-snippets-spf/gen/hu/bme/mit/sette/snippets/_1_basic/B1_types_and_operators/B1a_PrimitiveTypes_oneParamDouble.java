package hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators;

import hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators.B1a_PrimitiveTypes;

public final class B1a_PrimitiveTypes_oneParamDouble {
    public static void main(String[] args) throws Exception {
        B1a_PrimitiveTypes.oneParamDouble(1.0);
    }
}
