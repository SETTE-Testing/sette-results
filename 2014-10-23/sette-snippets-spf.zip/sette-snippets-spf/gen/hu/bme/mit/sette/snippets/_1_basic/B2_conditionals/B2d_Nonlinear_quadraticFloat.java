package hu.bme.mit.sette.snippets._1_basic.B2_conditionals;

import hu.bme.mit.sette.snippets._1_basic.B2_conditionals.B2d_Nonlinear;

public final class B2d_Nonlinear_quadraticFloat {
    public static void main(String[] args) throws Exception {
        B2d_Nonlinear.quadraticFloat(1.0f, 1.0f);
    }
}
