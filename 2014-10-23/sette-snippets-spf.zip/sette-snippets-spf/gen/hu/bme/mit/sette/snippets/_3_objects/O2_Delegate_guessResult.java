package hu.bme.mit.sette.snippets._3_objects;

import hu.bme.mit.sette.snippets._3_objects.O2_Delegate;

public final class O2_Delegate_guessResult {
    public static void main(String[] args) throws Exception {
        O2_Delegate.guessResult(null, 1, 1, 1);
    }
}
