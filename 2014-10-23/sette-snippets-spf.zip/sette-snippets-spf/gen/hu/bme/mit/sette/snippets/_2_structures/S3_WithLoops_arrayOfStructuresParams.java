package hu.bme.mit.sette.snippets._2_structures;

import hu.bme.mit.sette.snippets._2_structures.S3_WithLoops;

public final class S3_WithLoops_arrayOfStructuresParams {
    public static void main(String[] args) throws Exception {
        S3_WithLoops.arrayOfStructuresParams(null, null);
    }
}
