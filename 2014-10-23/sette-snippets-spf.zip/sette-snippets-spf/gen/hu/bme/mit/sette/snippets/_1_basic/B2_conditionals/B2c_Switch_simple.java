package hu.bme.mit.sette.snippets._1_basic.B2_conditionals;

import hu.bme.mit.sette.snippets._1_basic.B2_conditionals.B2c_Switch;

public final class B2c_Switch_simple {
    public static void main(String[] args) throws Exception {
        B2c_Switch.simple(1);
    }
}
