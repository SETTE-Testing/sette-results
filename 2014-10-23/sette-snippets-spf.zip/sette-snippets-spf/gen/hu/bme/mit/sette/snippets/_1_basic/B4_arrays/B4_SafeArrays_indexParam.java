package hu.bme.mit.sette.snippets._1_basic.B4_arrays;

import hu.bme.mit.sette.snippets._1_basic.B4_arrays.B4_SafeArrays;

public final class B4_SafeArrays_indexParam {
    public static void main(String[] args) throws Exception {
        B4_SafeArrays.indexParam(1);
    }
}
