package hu.bme.mit.sette.snippets._1_basic.B3_loops;

import hu.bme.mit.sette.snippets._1_basic.B3_loops.B3a_While;

public final class B3a_While_withConditionNoLimit {
    public static void main(String[] args) throws Exception {
        B3a_While.withConditionNoLimit(1);
    }
}
