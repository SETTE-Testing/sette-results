package hu.bme.mit.sette.snippets._1_basic.B5_functions;

import hu.bme.mit.sette.snippets._1_basic.B5_functions.B5a_CallPrivate;

public final class B5a_CallPrivate_conditionalCall {
    public static void main(String[] args) throws Exception {
        B5a_CallPrivate.conditionalCall(1, 1, false);
    }
}
