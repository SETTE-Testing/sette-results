package hu.bme.mit.sette.snippets._1_basic.B5_functions;

import hu.bme.mit.sette.snippets._1_basic.B5_functions.B5b_UnlimitedRecursive;

public final class B5b_UnlimitedRecursive_simple {
    public static void main(String[] args) throws Exception {
        B5b_UnlimitedRecursive.simple(1);
    }
}
