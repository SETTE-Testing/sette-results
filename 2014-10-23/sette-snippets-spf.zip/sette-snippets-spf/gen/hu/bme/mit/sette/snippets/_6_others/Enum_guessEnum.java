package hu.bme.mit.sette.snippets._6_others;

import hu.bme.mit.sette.snippets._6_others.Enum;

public final class Enum_guessEnum {
    public static void main(String[] args) throws Exception {
        Enum.guessEnum(null);
    }
}
