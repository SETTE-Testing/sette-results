package hu.bme.mit.sette.snippets._1_basic.B3_loops;

import hu.bme.mit.sette.snippets._1_basic.B3_loops.B3a_While;

public final class B3a_While_withLimit {
    public static void main(String[] args) throws Exception {
        B3a_While.withLimit(1);
    }
}
