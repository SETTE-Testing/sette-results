package hu.bme.mit.sette.snippets._5_library;

import hu.bme.mit.sette.snippets._5_library.L2_Strings_Java7;

public final class L2_Strings_Java7_switchString {
    public static void main(String[] args) throws Exception {
        L2_Strings_Java7.switchString(null);
    }
}
