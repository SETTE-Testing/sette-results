package hu.bme.mit.sette.snippets._1_basic.B3_loops;

import hu.bme.mit.sette.snippets._1_basic.B3_loops.B3b_For;

public final class B3b_For_withConditionAndLimit {
    public static void main(String[] args) throws Exception {
        B3b_For.withConditionAndLimit(1);
    }
}
