package hu.bme.mit.sette.snippets._3_objects;

import hu.bme.mit.sette.snippets._3_objects.O3c_Abstract;

public final class O3c_Abstract_guessImpossible {
    public static void main(String[] args) throws Exception {
        O3c_Abstract.guessImpossible(null, 1);
    }
}
