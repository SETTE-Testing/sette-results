package hu.bme.mit.sette.snippets._1_basic.B6_exceptions;

import hu.bme.mit.sette.snippets._1_basic.B6_exceptions.B6a_CheckedExceptions;

public final class B6a_CheckedExceptions_tryCatch {
    public static void main(String[] args) throws Exception {
        B6a_CheckedExceptions.tryCatch(1, 1);
    }
}
