package hu.bme.mit.sette.snippets._1_basic.B5_functions;

import hu.bme.mit.sette.snippets._1_basic.B5_functions.B5a_CallPublic;

public final class B5a_CallPublic_simple {
    public static void main(String[] args) throws Exception {
        B5a_CallPublic.simple(1, 1);
    }
}
