package hu.bme.mit.sette.snippets._2_structures;

import hu.bme.mit.sette.snippets._2_structures.S4_StructureInStructure;

public final class S4_StructureInStructure_guessCoordinates {
    public static void main(String[] args) throws Exception {
        S4_StructureInStructure.guessCoordinates(null, null);
    }
}
