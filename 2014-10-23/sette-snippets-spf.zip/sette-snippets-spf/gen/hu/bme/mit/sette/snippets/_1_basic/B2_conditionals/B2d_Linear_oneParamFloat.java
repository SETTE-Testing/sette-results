package hu.bme.mit.sette.snippets._1_basic.B2_conditionals;

import hu.bme.mit.sette.snippets._1_basic.B2_conditionals.B2d_Linear;

public final class B2d_Linear_oneParamFloat {
    public static void main(String[] args) throws Exception {
        B2d_Linear.oneParamFloat(1.0f);
    }
}
