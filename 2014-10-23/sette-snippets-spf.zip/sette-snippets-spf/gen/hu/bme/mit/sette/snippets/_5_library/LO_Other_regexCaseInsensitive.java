package hu.bme.mit.sette.snippets._5_library;

import hu.bme.mit.sette.snippets._5_library.LO_Other;

public final class LO_Other_regexCaseInsensitive {
    public static void main(String[] args) throws Exception {
        LO_Other.regexCaseInsensitive(null);
    }
}
