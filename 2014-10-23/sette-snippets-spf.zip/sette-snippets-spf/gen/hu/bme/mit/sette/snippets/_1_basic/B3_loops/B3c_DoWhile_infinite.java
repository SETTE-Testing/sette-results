package hu.bme.mit.sette.snippets._1_basic.B3_loops;

import hu.bme.mit.sette.snippets._1_basic.B3_loops.B3c_DoWhile;

public final class B3c_DoWhile_infinite {
    public static void main(String[] args) throws Exception {
        B3c_DoWhile.infinite(1);
    }
}
