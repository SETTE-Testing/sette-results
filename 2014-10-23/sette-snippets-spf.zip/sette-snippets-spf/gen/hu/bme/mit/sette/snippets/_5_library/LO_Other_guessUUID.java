package hu.bme.mit.sette.snippets._5_library;

import hu.bme.mit.sette.snippets._5_library.LO_Other;

public final class LO_Other_guessUUID {
    public static void main(String[] args) throws Exception {
        LO_Other.guessUUID(null);
    }
}
