package hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators;

import hu.bme.mit.sette.snippets._1_basic.B1_types_and_operators.B1e_BitwiseOperators;

public final class B1e_BitwiseOperators_negate {
    public static void main(String[] args) throws Exception {
        B1e_BitwiseOperators.negate(1);
    }
}
